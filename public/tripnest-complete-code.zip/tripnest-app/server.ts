import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI client if GEMINI_API_KEY is available
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  } catch (e) {
    console.warn('Failed to initialize GoogleGenAI client:', e);
  }
}

// -------------------------------------------------------------
// IN-MEMORY / PERSISTENT DATA LAYER (PostgreSQL Seed Mirror)
// -------------------------------------------------------------

interface ServerUser {
  id: string;
  fullName: string;
  email: string;
  avatarUrl: string;
  country: string;
  preferredCurrency: string;
  travelPreferences: string[];
  role: string;
  createdAt: string;
  isGoogleUser?: boolean;
  provider?: 'local' | 'google';
}

const USERS: ServerUser[] = [
  {
    id: 'usr-1',
    fullName: 'Lara Croft',
    email: 'lara@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    country: 'United Kingdom',
    preferredCurrency: 'USD',
    travelPreferences: ['Historical', 'Adventure', 'Photography'],
    role: 'TRAVELER',
    createdAt: '2026-01-15T08:00:00Z',
  },
  {
    id: 'usr-2',
    fullName: 'Madhav Sharma',
    email: 'madhav@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    country: 'India',
    preferredCurrency: 'INR',
    travelPreferences: ['Cultural', 'Beaches', 'Food'],
    role: 'GROUP_ADMIN',
    createdAt: '2026-01-20T10:00:00Z',
  },
  {
    id: 'usr-admin',
    fullName: 'TripNest Admin',
    email: 'admin@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    country: 'United States',
    preferredCurrency: 'USD',
    travelPreferences: ['System Management', 'Analytics'],
    role: 'ADMIN',
    createdAt: '2026-01-01T00:00:00Z',
  },
];

let TRIPS = [
  {
    id: 'trip-rome-2026',
    tripName: 'Rome Cultural Escape',
    description: 'An immersive 5-day journey through the heart of the Roman Empire, classical renaissance art, and authentic Italian gastronomy.',
    destination: 'Rome',
    country: 'Italy',
    startDate: '2026-10-10',
    endDate: '2026-10-15',
    travelers: 2,
    budget: 3200,
    spent: 2450,
    currency: 'USD',
    status: 'UPCOMING',
    visibility: 'GROUP',
    coverImage: '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    ownerId: 'usr-1',
    ownerName: 'Lara Croft',
    travelStyle: 'Standard',
    groupId: 'grp-rome',
    coordinates: { lat: 41.9028, lng: 12.4964 },
    createdAt: '2026-02-01T10:00:00Z',
    updatedAt: '2026-02-10T14:30:00Z',
  },
  {
    id: 'trip-goa-2026',
    tripName: 'Goa Coastal Odyssey',
    description: 'Sun, sand, Portuguese heritage architecture, and coastal seafood explorations with friends.',
    destination: 'Goa',
    country: 'India',
    startDate: '2026-11-05',
    endDate: '2026-11-10',
    travelers: 4,
    budget: 65000,
    spent: 38200,
    currency: 'INR',
    status: 'PLANNING',
    visibility: 'GROUP',
    coverImage: '/src/assets/images/dest_goa_beach_1790172797821.jpg',
    ownerId: 'usr-2',
    ownerName: 'Madhav Sharma',
    travelStyle: 'Adventure',
    groupId: 'grp-goa',
    coordinates: { lat: 15.2993, lng: 74.124 },
    createdAt: '2026-02-12T09:00:00Z',
    updatedAt: '2026-02-15T11:20:00Z',
  },
  {
    id: 'trip-bali-2026',
    tripName: 'Bali Spiritual & Nature Retreat',
    description: 'Exploring ancient water temples, Ubud emerald rice terraces, and Mount Batur sunrise hike.',
    destination: 'Bali',
    country: 'Indonesia',
    startDate: '2026-12-01',
    endDate: '2026-12-08',
    travelers: 2,
    budget: 2800,
    spent: 950,
    currency: 'USD',
    status: 'PLANNING',
    visibility: 'PRIVATE',
    coverImage: '/src/assets/images/dest_bali_temple_1790172783309.jpg',
    ownerId: 'usr-1',
    ownerName: 'Lara Croft',
    travelStyle: 'Luxury',
    coordinates: { lat: -8.4095, lng: 115.1889 },
    createdAt: '2026-02-18T16:00:00Z',
    updatedAt: '2026-02-18T16:00:00Z',
  },
];

let ITINERARY_DAYS = [
  {
    id: 'day-rome-1',
    tripId: 'trip-rome-2026',
    dayNumber: 1,
    date: '2026-10-10',
    title: 'Arrival & Ancient Roman Forum',
    summary: 'Touchdown in Leonardo da Vinci airport, hotel check-in in Monti, followed by an afternoon at the Colosseum and Roman Forum.',
    activities: [
      {
        id: 'act-1',
        dayId: 'day-rome-1',
        tripId: 'trip-rome-2026',
        name: 'Check into Hotel Artemide',
        description: 'Boutique hotel in Via Nazionale. Drop off baggage and refresh.',
        startTime: '10:00',
        endTime: '11:00',
        location: 'Via Nazionale 22, Rome',
        category: 'Hotel',
        cost: 320,
        currency: 'USD',
        notes: 'Reservation code: IT-ROM-9821. Late checkout requested.',
        priority: 'High',
        isCompleted: true,
        coordinates: { lat: 41.9015, lng: 12.4925 },
      },
      {
        id: 'act-2',
        dayId: 'day-rome-1',
        tripId: 'trip-rome-2026',
        name: 'Colosseum & Roman Forum Tour',
        description: 'Skip-the-line VIP guided tour of the gladiators arena and Roman Forum.',
        startTime: '13:00',
        endTime: '16:00',
        location: 'Piazza del Colosseo 1, Rome',
        category: 'Sightseeing',
        cost: 110,
        currency: 'USD',
        notes: 'Bring ID and e-tickets. Sunscreen recommended.',
        priority: 'High',
        isCompleted: true,
        coordinates: { lat: 41.8902, lng: 12.4922 },
      },
      {
        id: 'act-3',
        dayId: 'day-rome-1',
        tripId: 'trip-rome-2026',
        name: 'Dinner at Trattoria Monti',
        description: 'Authentic cacio e pepe, artichokes alla romana, and local Frascati white wine.',
        startTime: '19:30',
        endTime: '21:30',
        location: 'Via di San Vito 13, Rome',
        category: 'Food',
        cost: 95,
        currency: 'USD',
        notes: 'Table booked under Croft for 2 persons.',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.8967, lng: 12.5011 },
      },
    ],
  },
  {
    id: 'day-rome-2',
    tripId: 'trip-rome-2026',
    dayNumber: 2,
    date: '2026-10-11',
    title: 'Vatican City & Trastevere Evenings',
    summary: 'St. Peter Basilica, Sistine Chapel, followed by a scenic walk across Tiber river for gelato and sunset.',
    activities: [
      {
        id: 'act-4',
        dayId: 'day-rome-2',
        tripId: 'trip-rome-2026',
        name: 'Vatican Museums & Sistine Chapel',
        description: 'Explore Renaissance masterpieces by Michelangelo and Raphael.',
        startTime: '08:30',
        endTime: '12:00',
        location: 'Viale Vaticano, 00165 Roma',
        category: 'Culture',
        cost: 85,
        currency: 'USD',
        notes: 'Strict dress code: shoulders and knees covered.',
        priority: 'High',
        isCompleted: false,
        coordinates: { lat: 41.9065, lng: 12.4536 },
      },
      {
        id: 'act-5',
        dayId: 'day-rome-2',
        tripId: 'trip-rome-2026',
        name: 'Piazza Navona & Pantheon',
        description: 'Stroll around Berninis Fountain of the Four Rivers and the ancient Roman Pantheon.',
        startTime: '14:30',
        endTime: '17:00',
        location: 'Piazza della Rotonda, Rome',
        category: 'Sightseeing',
        cost: 15,
        currency: 'USD',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.8986, lng: 12.4769 },
      },
      {
        id: 'act-6',
        dayId: 'day-rome-2',
        tripId: 'trip-rome-2026',
        name: 'Trastevere Sunset & Wine Bar',
        description: 'Charming cobblestone alleyways, street performers, and natural wine tasting.',
        startTime: '18:30',
        endTime: '21:00',
        location: 'Piazza di Santa Maria in Trastevere, Rome',
        category: 'Entertainment',
        cost: 60,
        currency: 'USD',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.8895, lng: 12.4705 },
      },
    ],
  },
  {
    id: 'day-rome-3',
    tripId: 'trip-rome-2026',
    dayNumber: 3,
    date: '2026-10-12',
    title: 'Trevi Fountain & Villa Borghese Gardens',
    summary: 'Coin toss at Trevi, luxury shopping near Spanish Steps, and renting bicycles in Borghese park.',
    activities: [
      {
        id: 'act-7',
        dayId: 'day-rome-3',
        tripId: 'trip-rome-2026',
        name: 'Early Morning Trevi Fountain Toss',
        description: 'Visit at 07:30 to beat crowds and toss a coin over left shoulder.',
        startTime: '07:30',
        endTime: '08:45',
        location: 'Piazza di Trevi, Rome',
        category: 'Sightseeing',
        cost: 5,
        currency: 'USD',
        priority: 'Low',
        isCompleted: false,
        coordinates: { lat: 41.9009, lng: 12.4833 },
      },
      {
        id: 'act-8',
        dayId: 'day-rome-3',
        tripId: 'trip-rome-2026',
        name: 'Villa Borghese Bicycle Rental & Gallery',
        description: 'Relaxed afternoon cycling through gardens and visiting the Borghese sculpture gallery.',
        startTime: '11:00',
        endTime: '15:00',
        location: 'Piazzale Scipione Borghese 5, Rome',
        category: 'Nature',
        cost: 45,
        currency: 'USD',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.9142, lng: 12.4922 },
      },
    ],
  },
];

let EXPENSES = [
  {
    id: 'exp-1',
    tripId: 'trip-rome-2026',
    title: 'Roundtrip Flights (London Heathrow to Fiumicino)',
    amount: 720,
    currency: 'USD',
    category: 'Flights',
    date: '2026-09-01',
    paidById: 'usr-1',
    paidByName: 'Lara Croft',
    paymentMethod: 'Credit Card',
    notes: 'British Airways flight BA554 and BA557.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 360, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 360, settled: false },
    ],
  },
  {
    id: 'exp-2',
    tripId: 'trip-rome-2026',
    title: 'Hotel Artemide (5 Nights)',
    amount: 1100,
    currency: 'USD',
    category: 'Accommodation',
    date: '2026-09-15',
    paidById: 'usr-1',
    paidByName: 'Lara Croft',
    paymentMethod: 'Credit Card',
    notes: 'Superior Queen room with daily breakfast.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 550, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 550, settled: false },
    ],
  },
  {
    id: 'exp-3',
    tripId: 'trip-rome-2026',
    title: 'Colosseum & Vatican Guided Passes',
    amount: 195,
    currency: 'USD',
    category: 'Activities',
    date: '2026-09-20',
    paidById: 'usr-2',
    paidByName: 'Madhav Sharma',
    paymentMethod: 'UPI',
    notes: 'Skip-the-line official tickets for 2 adults.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 97.5, settled: false },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 97.5, settled: true },
    ],
  },
  {
    id: 'exp-4',
    tripId: 'trip-rome-2026',
    title: 'Airport Leonardo Express Train Transfers',
    amount: 56,
    currency: 'USD',
    category: 'Transportation',
    date: '2026-10-10',
    paidById: 'usr-2',
    paidByName: 'Madhav Sharma',
    paymentMethod: 'Credit Card',
    notes: 'Train tickets from Fiumicino to Roma Termini.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 28, settled: false },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 28, settled: true },
    ],
  },
  {
    id: 'exp-5',
    tripId: 'trip-rome-2026',
    title: 'Trattoria Monti Welcome Dinner',
    amount: 140,
    currency: 'USD',
    category: 'Food',
    date: '2026-10-10',
    paidById: 'usr-1',
    paidByName: 'Lara Croft',
    paymentMethod: 'Cash',
    notes: 'Pasta, starters, and house red wine.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 70, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 70, settled: false },
    ],
  },
];

let GROUPS = [
  {
    id: 'grp-rome',
    name: 'Rome Explorers Squad',
    description: 'Planning discussions, shared budget, and itinerary sync for Rome Autumn 2026.',
    imageUrl: '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    tripId: 'trip-rome-2026',
    createdAt: '2026-02-01T10:00:00Z',
    members: [
      {
        userId: 'usr-1',
        name: 'Lara Croft',
        email: 'lara@tripnest.com',
        avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
        role: 'Owner',
        joinedAt: '2026-02-01T10:00:00Z',
      },
      {
        userId: 'usr-2',
        name: 'Madhav Sharma',
        email: 'madhav@tripnest.com',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'Admin',
        joinedAt: '2026-02-02T11:00:00Z',
      },
    ],
  },
  {
    id: 'grp-goa',
    name: 'Goa Coastal Crew',
    description: 'Beach hopping, scuba diving, and night market trip group.',
    imageUrl: '/src/assets/images/dest_goa_beach_1790172797821.jpg',
    tripId: 'trip-goa-2026',
    createdAt: '2026-02-12T09:00:00Z',
    members: [
      {
        userId: 'usr-2',
        name: 'Madhav Sharma',
        email: 'madhav@tripnest.com',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'Owner',
        joinedAt: '2026-02-12T09:00:00Z',
      },
    ],
  },
];

let DOCUMENTS = [
  {
    id: 'doc-1',
    tripId: 'trip-rome-2026',
    name: 'Schengen Visa Confirmation.pdf',
    category: 'Visa',
    fileSize: '1.4 MB',
    fileType: 'application/pdf',
    uploadDate: '2026-08-20',
    expiryDate: '2027-02-20',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Multi-entry Schengen visa valid for 90 days stay.',
  },
  {
    id: 'doc-2',
    tripId: 'trip-rome-2026',
    name: 'BA554 Flight Boarding Pass.pdf',
    category: 'Flight Tickets',
    fileSize: '820 KB',
    fileType: 'application/pdf',
    uploadDate: '2026-09-02',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Terminal 5 Heathrow, seats 14A & 14B.',
  },
  {
    id: 'doc-3',
    tripId: 'trip-rome-2026',
    name: 'Hotel Artemide Booking Voucher.pdf',
    category: 'Hotel Bookings',
    fileSize: '650 KB',
    fileType: 'application/pdf',
    uploadDate: '2026-09-15',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Check-in Oct 10 14:00, Check-out Oct 15 11:00.',
  },
  {
    id: 'doc-4',
    tripId: 'trip-rome-2026',
    name: 'Allianz Global Travel Insurance Policy.pdf',
    category: 'Travel Insurance',
    fileSize: '2.1 MB',
    fileType: 'application/pdf',
    uploadDate: '2026-08-25',
    expiryDate: '2026-11-01',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Comprehensive medical and flight cancellation coverage.',
  },
];

let NOTIFICATIONS = [
  {
    id: 'notif-1',
    title: 'Flight Check-in Reminder',
    message: 'Online check-in for flight BA554 to Rome opens in 48 hours.',
    type: 'TRIP',
    isRead: false,
    timestamp: '10 minutes ago',
    actionUrl: '/trips/trip-rome-2026',
  },
  {
    id: 'notif-2',
    title: 'Budget Milestone Alert',
    message: 'Rome Cultural Escape is at 76% of estimated expenditure ($2,450 / $3,200).',
    type: 'BUDGET',
    isRead: false,
    timestamp: '2 hours ago',
    actionUrl: '/trips/trip-rome-2026',
  },
  {
    id: 'notif-3',
    title: 'New Activity Proposal by TripNest AI',
    message: 'AI Copilot recommended an evening Trastevere Wine & Cheese walk based on your food preference.',
    type: 'AI',
    isRead: true,
    timestamp: '1 day ago',
    actionUrl: '/trips/trip-rome-2026',
  },
  {
    id: 'notif-4',
    title: 'Group Invitation Accepted',
    message: 'Madhav Sharma joined Rome Explorers Squad.',
    type: 'GROUP',
    isRead: true,
    timestamp: '3 days ago',
    actionUrl: '/groups',
  },
];

let FAVORITES = ['dest-rome', 'dest-bali', 'dest-paris'];

const DESTINATIONS = [
  // --- INDIA DESTINATIONS ---
  {
    id: 'dest-jaipur',
    name: 'Jaipur',
    country: 'India',
    region: 'South Asia',
    category: 'Culture',
    rating: 4.9,
    shortDescription: 'The Pink City of Rajasthan with majestic hilltop Amber Fort, royal palaces, and vibrant bazaars.',
    longDescription: 'Jaipur enchants travelers with its rose-hued terracotta architecture, astronomical marvel Jantar Mantar, opulent City Palace, and rich artisanal textiles and gemstone jewelry.',
    imageUrl: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 45,
    bestTimeToVisit: 'October - March',
    currentWeather: { temp: 28, condition: 'Sunny & Pleasant', icon: 'Sun' },
    topAttractions: [
      { name: 'Amber Fort & Elephant Courtyard', description: 'Hilltop fort palace with Sheesh Mahal mirror mosaics and Maota Lake reflection.', estimatedCost: 7 },
      { name: 'Hawa Mahal (Palace of Winds)', description: 'Iconic five-story pink sandstone facade with 953 ornate latticed jharokhas.', estimatedCost: 3 },
      { name: 'City Palace & Chandra Mahal', description: 'Grand royal residence blending Rajput, Mughal, and European architecture.', estimatedCost: 10 },
      { name: 'Nahargarh Fort Sunset Viewpoint', description: 'Historic fortress overlooking panoramic sunset vistas of Jaipur city.', estimatedCost: 4 },
    ],
    travelTips: ['Take an audio guide at Amber Fort for fascinating royal history.', 'Try authentic Dal Baati Churma and Ghewar sweets in old city markets.'],
    safetyInfo: 'Very friendly and safe; agree on auto-rickshaw fares or use rideshare apps.',
    coordinates: { lat: 26.9124, lng: 75.7873 },
  },
  {
    id: 'dest-varanasi',
    name: 'Varanasi',
    country: 'India',
    region: 'South Asia',
    category: 'Culture',
    rating: 4.8,
    shortDescription: 'Spiritual heart of India along the holy Ganges with ancient ghats, morning boat rides, and evening Ganga Aarti.',
    longDescription: 'One of the worlds oldest continually inhabited cities, Varanasi is an extraordinary sensory and spiritual journey. Witness flickering oil lamps at Dashashwamedh Ghat and tranquil sunrise over sacred waters.',
    imageUrl: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 35,
    bestTimeToVisit: 'November - February',
    currentWeather: { temp: 26, condition: 'Clear Skies', icon: 'Sun' },
    topAttractions: [
      { name: 'Dashashwamedh Ghat Evening Aarti', description: 'Hypnotic synchronized Vedic chants, brass lamps, and incense ceremony at dusk.', estimatedCost: 0 },
      { name: 'Ganges Sunrise Boat Pilgrimage', description: 'Dawn rowboat ride watching morning rituals across historic riverside palaces.', estimatedCost: 6 },
      { name: 'Kashi Vishwanath Golden Temple', description: 'One of the twelve sacred Jyotirlinga shrines with magnificent gold spire.', estimatedCost: 0 },
      { name: 'Sarnath Deer Park & Stupa', description: 'Ancient UNESCO site where Gautama Buddha first taught the Dharma.', estimatedCost: 5 },
    ],
    travelTips: ['Book a traditional wooden hand-rowed boat at dawn for serene photographs.', 'Savor famous Banarasi Paan, Malaiyo froth sweet, and Kachori Sabzi.'],
    safetyInfo: 'Keep your belongings secure in crowded narrow alleyways (galis).',
    coordinates: { lat: 25.3176, lng: 82.9739 },
  },
  {
    id: 'dest-kerala',
    name: 'Kerala Backwaters',
    country: 'India',
    region: 'South Asia',
    category: 'Nature',
    rating: 4.9,
    shortDescription: 'Gods Own Country featuring emerald canal cruises on traditional houseboats, spice hills, and Ayurvedic wellness.',
    longDescription: 'Drift past serene coconut groves and paddy fields in Alleppey, wander aromatic tea plantations in Munnar, and experience Kathakali classical dance and Portuguese colonial quarters in Fort Kochi.',
    imageUrl: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 55,
    bestTimeToVisit: 'September - March',
    currentWeather: { temp: 28, condition: 'Tropical Warm', icon: 'CloudSun' },
    topAttractions: [
      { name: 'Alleppey Kettuvallam Houseboat Cruise', description: 'Overnight journey through tranquil lagoons with fresh Karimeen fish dining.', estimatedCost: 65 },
      { name: 'Munnar Tea Hills & Eravikulam', description: 'Rolling emerald tea gardens, misty viewpoints, and Nilgiri Tahr mountain goats.', estimatedCost: 8 },
      { name: 'Fort Kochi Chinese Fishing Nets', description: 'Colonial spice warehouses, art cafes, and iconic counterweighted shore nets.', estimatedCost: 0 },
      { name: 'Periyar Wildlife Sanctuary', description: 'Boat safari viewing wild elephants, sambar deer, and rare birds.', estimatedCost: 15 },
    ],
    travelTips: ['Opt for an eco-friendly solar or electric houseboat to preserve the pristine backwaters.', 'Schedule an authentic Ayurvedic Abhyanga herbal massage.'],
    safetyInfo: 'Extremely peaceful, welcoming, and traveler-friendly state with high safety standards.',
    coordinates: { lat: 9.4981, lng: 76.3388 },
  },
  {
    id: 'dest-ladakh',
    name: 'Ladakh',
    country: 'India',
    region: 'South Asia',
    category: 'Adventure',
    rating: 5.0,
    shortDescription: 'The Land of High Passes featuring surreal mountain moonscapes, azure Pangong Lake, and cliffside Buddhist gompas.',
    longDescription: 'High in the Himalayas, Ladakh offers dramatic stark valleys, high-altitude passes like Khardung La, prayer-flag festooned monasteries like Thiksey and Hemis, and the striking blue waters of Pangong Tso.',
    imageUrl: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 60,
    bestTimeToVisit: 'May - September',
    currentWeather: { temp: 15, condition: 'Crisp Mountain Breeze', icon: 'Sun' },
    topAttractions: [
      { name: 'Pangong Tso High-Altitude Lake', description: 'Color-changing endorheic lake extending from India to Tibet at 4,225 meters.', estimatedCost: 10 },
      { name: 'Nubra Valley & Hunder Sand Dunes', description: 'Double-humped Bactrian camel safaris in high-altitude cold desert dunes.', estimatedCost: 12 },
      { name: 'Thiksey & Hemis Monasteries', description: 'Mini-Potala architectural complex with giant golden Maitreya Buddha.', estimatedCost: 3 },
      { name: 'Khardung La Mountain Pass', description: 'World-renowned motorable pass with fluttering Tibetan prayer flags.', estimatedCost: 5 },
    ],
    travelTips: ['Rest for at least 36 hours in Leh upon arrival for proper altitude acclimatization.', 'Keep multiple photocopies of Inner Line Permits (ILP).'],
    safetyInfo: 'Hydrate well and monitor symptoms of Acute Mountain Sickness (AMS).',
    coordinates: { lat: 34.1526, lng: 77.5771 },
  },
  {
    id: 'dest-manali',
    name: 'Manali & Solang',
    country: 'India',
    region: 'South Asia',
    category: 'Mountains',
    rating: 4.8,
    shortDescription: 'Snow-capped Himalayan peaks, roaring Beas river rapids, pine forests, and Solang Valley adventures.',
    longDescription: 'Nestled in the Kullu Valley, Manali combines quaint wooden Old Manali cafes, hot sulphur springs in Vashisht, paragliding over Solang Valley, and high-altitude trips through Atal Tunnel toward Rohtang Pass.',
    imageUrl: 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 40,
    bestTimeToVisit: 'October - June (Winter for Snow, Summer for Treks)',
    currentWeather: { temp: 14, condition: 'Mountain Alpine', icon: 'CloudSun' },
    topAttractions: [
      { name: 'Solang Valley Adventure Arena', description: 'Paragliding, zorbing, ATV quad biking, and winter ski slopes.', estimatedCost: 20 },
      { name: 'Hadimba Wooden Forest Temple', description: 'Historic 1553 pagoda-style wooden temple surrounded by giant deodar cedars.', estimatedCost: 1 },
      { name: 'Rohtang Pass & Atal Tunnel', description: 'Gateway to Lahaul with panoramic glaciers and perpetual snow cover.', estimatedCost: 18 },
      { name: 'Jogini Waterfall Pine Trek', description: 'Scenic forest hike climbing up to a thunderous two-tiered cascade.', estimatedCost: 0 },
    ],
    travelTips: ['Old Manali is best for peaceful artisan cafes and acoustic live music.', 'Get your Rohtang Pass vehicle permit online 2-3 days in advance.'],
    safetyInfo: 'Drive cautiously along winding mountain roads; dress in layers.',
    coordinates: { lat: 32.2432, lng: 77.1892 },
  },
  {
    id: 'dest-udaipur',
    name: 'Udaipur',
    country: 'India',
    region: 'South Asia',
    category: 'Popular',
    rating: 4.9,
    shortDescription: 'The Venice of the East with shimmering Lake Pichola, floating marble palaces, and sunset boat rides.',
    longDescription: 'Surrounded by the ancient Aravalli Hills, Udaipur radiates romance. Explore the regal City Palace, dine lakeside by candlelit ghats, and admire courtyard fountain gardens in Saheliyon-ki-Bari.',
    imageUrl: 'https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 50,
    bestTimeToVisit: 'October - March',
    currentWeather: { temp: 27, condition: 'Pleasant & Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Lake Pichola Sunset Boat Cruise', description: 'Sail past Taj Lake Palace and Jag Mandir island with palace illumination.', estimatedCost: 10 },
      { name: 'Udaipur City Palace Museum', description: 'Rajasthan’s largest palace complex with mirror gallery and peacock courtyards.', estimatedCost: 8 },
      { name: 'Jagdish 1651 Carved Temple', description: 'Magnificent Indo-Aryan stone temple adorned with intricate carvings.', estimatedCost: 0 },
      { name: 'Monsoon Palace (Sajjangarh)', description: 'Hilltop astronomical castle offering 360-degree sunset views of Udaipur lakes.', estimatedCost: 5 },
    ],
    travelTips: ['Reserve a lakeside dinner table at Ambrai or Upre for unforgettable palace views.', 'Explore local Pichwai painting studios in the heritage quarters.'],
    safetyInfo: 'Very secure and calm heritage destination.',
    coordinates: { lat: 24.5854, lng: 73.7125 },
  },
  {
    id: 'dest-goa',
    name: 'Goa',
    country: 'India',
    region: 'South Asia',
    category: 'Beaches',
    rating: 4.7,
    shortDescription: 'Golden coastline fringed with palm trees, Portuguese cathedrals, and lively beach shacks.',
    longDescription: 'Goa offers a laid-back blend of susegad lifestyle, spice plantations, vibrant flea markets, water sports, and sunset drum circles.',
    imageUrl: '/src/assets/images/dest_goa_beach_1790172797821.jpg',
    averageCostPerDay: 50,
    bestTimeToVisit: 'November - February',
    currentWeather: { temp: 31, condition: 'Warm & Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Palolem & Agonda Beaches', description: 'Pristine crescent bays with dolphin boat tours and beach huts.', estimatedCost: 0 },
      { name: 'Basilica of Bom Jesus', description: 'UNESCO World Heritage 16th-century baroque cathedral.', estimatedCost: 0 },
      { name: 'Dudhsagar Waterfalls Trek', description: 'Four-tiered milky white waterfall inside Bhagwan Mahavir Sanctuary.', estimatedCost: 20 },
    ],
    travelTips: ['North Goa is great for nightlife and water sports; South Goa is peaceful and pristine.', 'Try the authentic Goan fish curry with local poi bread.'],
    safetyInfo: 'Safe tourist destination; adhere to lifeguard beach flags regarding sea currents.',
    coordinates: { lat: 15.2993, lng: 74.124 },
  },

  // --- INTERNATIONAL DESTINATIONS ---
  {
    id: 'dest-rome',
    name: 'Rome',
    country: 'Italy',
    region: 'Southern Europe',
    category: 'Historical',
    rating: 4.9,
    shortDescription: 'The Eternal City with 2,800 years of living history, baroque fountains, and legendary cuisine.',
    longDescription: 'Rome is an epic outdoor museum where ancient colosseums rise alongside bustling espresso cafes, cobblestone alleyways, and the sovereign Vatican City.',
    imageUrl: '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    averageCostPerDay: 160,
    bestTimeToVisit: 'April - May & September - October',
    currentWeather: { temp: 24, condition: 'Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Colosseum & Roman Forum', description: 'Grand amphitheater of gladiators and ancient political heart.', estimatedCost: 28 },
      { name: 'Vatican Museums & Sistine Chapel', description: 'Michelangelos fresco ceiling and papal collections.', estimatedCost: 32 },
      { name: 'Pantheon & Piazza Navona', description: 'Flawlessly preserved Roman temple with open dome oculus.', estimatedCost: 5 },
      { name: 'Trevi Fountain & Spanish Steps', description: 'Baroque masterpiece coin-toss fountain and rooftop views.', estimatedCost: 0 },
    ],
    travelTips: ['Always carry a refillable water bottle for Romes public nasoni fountains.', 'Book Vatican tickets at least 3 weeks ahead.', 'Tipping is not mandatory; rounded change is appreciated.'],
    safetyInfo: 'Very safe city; watch out for pickpockets on metro lines A and B.',
    coordinates: { lat: 41.9028, lng: 12.4964 },
  },
  {
    id: 'dest-kyoto',
    name: 'Kyoto',
    country: 'Japan',
    region: 'East Asia',
    category: 'Culture',
    rating: 5.0,
    shortDescription: 'Ancient imperial capital with 2,000 Buddhist temples, Arashiyama bamboo groves, and geisha tea culture.',
    longDescription: 'Kyoto is the cultural soul of Japan. Walk beneath thousands of vermilion torii gates at Fushimi Inari, wander zen rock gardens, taste matcha ceremonies in Uji, and spot geiko in Gion.',
    imageUrl: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 150,
    bestTimeToVisit: 'March - May & October - November',
    currentWeather: { temp: 19, condition: 'Clear', icon: 'Sun' },
    topAttractions: [
      { name: 'Fushimi Inari Taisha Shrine', description: 'Mountain trail winding through 10,000 vivid vermilion torii gates.', estimatedCost: 0 },
      { name: 'Kinkaku-ji (Golden Pavilion)', description: 'Zen Buddhist temple covered in pure gold leaf reflecting over mirror pond.', estimatedCost: 5 },
      { name: 'Arashiyama Bamboo Forest & Monkey Park', description: 'Towering green bamboo stalks swaying with the wind.', estimatedCost: 0 },
      { name: 'Gion Historic Geisha District', description: 'Preserved 17th-century wooden machiya merchant houses and teahouses.', estimatedCost: 0 },
    ],
    travelTips: ['Visit Fushimi Inari at 7:00 AM to enjoy tranquil trails before tour groups arrive.', 'Rent a bicycle to explore eastern Kyoto canal paths.'],
    safetyInfo: 'One of the safest cultural cities in the world.',
    coordinates: { lat: 35.0116, lng: 135.7681 },
  },
  {
    id: 'dest-tokyo',
    name: 'Tokyo',
    country: 'Japan',
    region: 'East Asia',
    category: 'Trending',
    rating: 5.0,
    shortDescription: 'Ultra-modern metropolis seamlessly juxtaposed with quiet Shinto shrines and legendary ramen bars.',
    longDescription: 'From neon-lit Shibuya crossing to serene Meiji Jingu shrine, Tokyo represents the peak of efficiency, culinary craftsmanship, and urban innovation.',
    imageUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 175,
    bestTimeToVisit: 'March - May & October - November',
    currentWeather: { temp: 18, condition: 'Clear', icon: 'Sun' },
    topAttractions: [
      { name: 'Senso-ji Temple Asakusa', description: 'Tokyos oldest Buddhist temple with Nakamise shopping street.', estimatedCost: 0 },
      { name: 'Shibuya Sky & Scramble Crossing', description: 'Open-air observation deck 229 meters above the worlds busiest crossing.', estimatedCost: 18 },
      { name: 'TeamLab Planets Immersive Art', description: 'Body-immersive digital art museum walking through water.', estimatedCost: 28 },
    ],
    travelTips: ['Get a digital Suica or Pasmo IC card on your phone for all trains and vending machines.', 'Trash cans are rare; keep a small bag with you.'],
    safetyInfo: 'One of the safest cities in the world.',
    coordinates: { lat: 35.6762, lng: 139.6503 },
  },
  {
    id: 'dest-paris',
    name: 'Paris',
    country: 'France',
    region: 'Western Europe',
    category: 'Popular',
    rating: 4.9,
    shortDescription: 'The City of Light, celebrated for haute couture, the Louvre, romantic Seine bridges, and cafe culture.',
    longDescription: 'Paris balances iconic architectural monuments with cobblestone artist corners in Montmartre, world-leading art galleries, and Michelin-starred dining.',
    imageUrl: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 190,
    bestTimeToVisit: 'June - August & September - October',
    currentWeather: { temp: 19, condition: 'Partly Cloudy', icon: 'Cloud' },
    topAttractions: [
      { name: 'Eiffel Tower & Champ de Mars', description: 'Wrought-iron lattice tower with panoramic observation decks.', estimatedCost: 30 },
      { name: 'Louvre Museum', description: 'Worlds largest art museum housing the Mona Lisa and Venus de Milo.', estimatedCost: 22 },
      { name: 'Musée d Orsay', description: 'Impressionist art housed in a magnificent former railway station.', estimatedCost: 16 },
    ],
    travelTips: ['Purchase Navigo Easy metro passes for convenience.', 'Many state museums are free on the first Sunday of each month.'],
    safetyInfo: 'Safe; be aware of petition scams and pickpockets near major attractions.',
    coordinates: { lat: 48.8566, lng: 2.3522 },
  },
  {
    id: 'dest-swiss-alps',
    name: 'Swiss Alps (Interlaken)',
    country: 'Switzerland',
    region: 'Western Europe',
    category: 'Mountains',
    rating: 4.9,
    shortDescription: 'Pristine turquoise glacial lakes, Jungfraujoch Top of Europe, and storybook alpine chalets.',
    longDescription: 'Situated between Lake Thun and Lake Brienz beneath the towering Eiger, Mönch, and Jungfrau peaks, Interlaken is the global capital for alpine beauty, cogwheel trains, and paragliding.',
    imageUrl: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 230,
    bestTimeToVisit: 'June - September (Hiking) or December - March (Skiing)',
    currentWeather: { temp: 16, condition: 'Alpine Sun', icon: 'Sun' },
    topAttractions: [
      { name: 'Jungfraujoch - Top of Europe', description: 'Cogwheel train to highest railway station in Europe at 3,454m with Aletsch Glacier.', estimatedCost: 140 },
      { name: 'Lauterbrunnen Valley of 72 Waterfalls', description: 'Deep glacial valley with Staubbach Falls falling over sheer vertical cliffs.', estimatedCost: 0 },
      { name: 'Lake Brienz Steam Cruise', description: 'Turquoise glacial water cruise stopping at Giessbach waterfalls.', estimatedCost: 35 },
    ],
    travelTips: ['Invest in a Swiss Travel Pass if taking multiple mountain railways and lake steamers.', 'Tap water everywhere in Switzerland is pure mountain spring quality.'],
    safetyInfo: 'Consistently ranked among the safest travel destinations globally.',
    coordinates: { lat: 46.6863, lng: 7.8632 },
  },
  {
    id: 'dest-reykjavik',
    name: 'Reykjavik & Golden Circle',
    country: 'Iceland',
    region: 'Northern Europe',
    category: 'Adventure',
    rating: 4.9,
    shortDescription: 'Land of Fire & Ice featuring dancing Northern Lights, geothermal Blue Lagoon, and erupting geysers.',
    longDescription: 'Experience volcanic black sand beaches at Vik, cascading Gullfoss waterfall, the tectonic rift at Thingvellir National Park, and relaxing mineral waters of the world-famous Blue Lagoon.',
    imageUrl: 'https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 210,
    bestTimeToVisit: 'September - March (Aurora) or June - August (Midnight Sun)',
    currentWeather: { temp: 9, condition: 'Breezy & Crisp', icon: 'Cloud' },
    topAttractions: [
      { name: 'Blue Lagoon Geothermal Spa', description: 'Soak in silica-rich milky blue waters amidst black lava fields.', estimatedCost: 85 },
      { name: 'Golden Circle (Gullfoss & Geysir)', description: 'Thunderous two-tier waterfall and Strokkur geyser blasting 30m into the sky.', estimatedCost: 0 },
      { name: 'Reynisfjara Black Sand Beach', description: 'Basalt sea stacks, roaring Atlantic swells, and columnar cliff formations.', estimatedCost: 0 },
    ],
    travelTips: ['Rent a 4WD vehicle if driving Iceland’s Ring Road.', 'Download Aurora forecast apps for real-time northern lights geomagnetic activity.'],
    safetyInfo: 'Zero violent crime; always respect warning signs near rogue ocean waves at Reynisfjara.',
    coordinates: { lat: 64.1466, lng: -21.9426 },
  },
  {
    id: 'dest-barcelona',
    name: 'Barcelona',
    country: 'Spain',
    region: 'Southern Europe',
    category: 'Popular',
    rating: 4.8,
    shortDescription: 'Gaudí’s surreal architectural wonderland, sun-drenched Mediterranean beaches, and tapas bars.',
    longDescription: 'From the staggering soaring towers of Sagrada Família to Park Güell mosaics and lively late-night pincho bars along El Born, Barcelona blends cosmopolitan energy with coastal relaxation.',
    imageUrl: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 155,
    bestTimeToVisit: 'May - June & September - October',
    currentWeather: { temp: 23, condition: 'Sunny & Warm', icon: 'Sun' },
    topAttractions: [
      { name: 'La Sagrada Família Basilica', description: 'Gaudí’s breathtaking UNESCO masterpiece with stained-glass forest columns.', estimatedCost: 26 },
      { name: 'Park Güell Mosaic Terraces', description: 'Colorful ceramic salamander and gingerbread gatehouses overlooking the sea.', estimatedCost: 10 },
      { name: 'Gothic Quarter (Barri Gòtic)', description: 'Medieval labyrinth of Roman ruins, lantern-lit tapas taverns, and plazas.', estimatedCost: 0 },
    ],
    travelTips: ['Lunch is the largest meal (1:30 - 3:30 PM); dinner starts late after 8:30 PM.', 'Pre-book Sagrada Família tickets online well in advance.'],
    safetyInfo: 'Be attentive to personal belongings around La Rambla and Metro stations.',
    coordinates: { lat: 41.3879, lng: 2.1699 },
  },
  {
    id: 'dest-santorini',
    name: 'Santorini',
    country: 'Greece',
    region: 'Southern Europe',
    category: 'Beaches',
    rating: 4.9,
    shortDescription: 'Caldera cliffside whitewashed villages, sapphire blue domes, and world-famous Aegean sunsets.',
    longDescription: 'Santorini is the crown jewel of the Cyclades. Wander pedestrian marble paths in Oia, hike the dramatic crater rim from Fira, swim at volcanic red beaches, and sip crisp Assyrtiko white wines.',
    imageUrl: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 200,
    bestTimeToVisit: 'April - November',
    currentWeather: { temp: 26, condition: 'Sunny & Aegean Breeze', icon: 'Sun' },
    topAttractions: [
      { name: 'Oia Castle Sunset Panorama', description: 'World-famous view of windmills and whitewashed houses glowing in golden hour.', estimatedCost: 0 },
      { name: 'Fira to Oia Caldera Rim Hike', description: 'Breathtaking 10km cliffside trail with endless views of the sunken volcano crater.', estimatedCost: 0 },
      { name: 'Santorini Catamaran Caldera Cruise', description: 'Sailing past Hot Springs, Red Beach, and White Beach with Greek BBQ.', estimatedCost: 95 },
    ],
    travelTips: ['Stay in Imerovigli for caldera views with fewer crowds than Oia.', 'Wear sturdy walking shoes for cobblestones and numerous staircases.'],
    safetyInfo: 'Very peaceful island with friendly local hospitality.',
    coordinates: { lat: 36.3932, lng: 25.4615 },
  },
  {
    id: 'dest-cairo',
    name: 'Cairo & Giza',
    country: 'Egypt',
    region: 'Middle East',
    category: 'Historical',
    rating: 4.7,
    shortDescription: 'Timeless cradle of civilization with the Great Pyramids of Giza, Sphinx, and Grand Egyptian Museum.',
    longDescription: 'Stand before the only surviving ancient wonder of the world at Giza, discover treasures of Tutankhamun, cruise the legendary Nile River on a wooden felucca, and haggle in Khan el-Khalili bazaar.',
    imageUrl: 'https://images.unsplash.com/photo-1572252009286-268acec5ca0a?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 70,
    bestTimeToVisit: 'October - April',
    currentWeather: { temp: 29, condition: 'Warm & Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Great Pyramids of Giza & Sphinx', description: '5,000-year-old monumental tombs of Khufu, Khafre, and Menkaure.', estimatedCost: 15 },
      { name: 'Grand Egyptian Museum (GEM)', description: 'State-of-the-art museum housing 100,000 pharaonic antiquities.', estimatedCost: 25 },
      { name: 'Khan el-Khalili Historic Souk', description: '14th-century labyrinth filled with spices, brass lanterns, and perfume oils.', estimatedCost: 0 },
    ],
    travelTips: ['Hire an official licensed Egyptologist guide for deep historical context.', 'Carry small denomination Egyptian pounds for tips (baksheesh).'],
    safetyInfo: 'Stick with licensed guides and tourist transport; use rideshare apps in Cairo.',
    coordinates: { lat: 30.0444, lng: 31.2357 },
  },
  {
    id: 'dest-bali',
    name: 'Bali',
    country: 'Indonesia',
    region: 'Southeast Asia',
    category: 'Beaches',
    rating: 4.8,
    shortDescription: 'Island of the Gods with lush emerald rice terraces, cliffside temples, and world-class surfing.',
    longDescription: 'From the cultural tranquility of Ubud to dramatic sunset sea cliffs at Uluwatu, Bali blends tropical wellness with vibrant island hospitality.',
    imageUrl: '/src/assets/images/dest_bali_temple_1790172783309.jpg',
    averageCostPerDay: 75,
    bestTimeToVisit: 'May - September',
    currentWeather: { temp: 29, condition: 'Tropical Breeze', icon: 'CloudSun' },
    topAttractions: [
      { name: 'Ulun Danu Bratan Water Temple', description: 'Iconic temple floating on Lake Bratan with volcanic backdrop.', estimatedCost: 5 },
      { name: 'Tegallalang Rice Terraces', description: 'Valley of verdant stepped emerald paddies and jungle swings.', estimatedCost: 4 },
      { name: 'Uluwatu Sunset Temple & Kecak Dance', description: 'Clifftop temple overlooking crashing Indian Ocean waves.', estimatedCost: 12 },
    ],
    travelTips: ['Rent a scooter only if you have an international driving permit.', 'Dress respectfully with a sarong when entering temples.'],
    safetyInfo: 'Safe destination; beware of wild monkeys snatching sunglasses at Uluwatu.',
    coordinates: { lat: -8.4095, lng: 115.1889 },
  },
  {
    id: 'dest-london',
    name: 'London',
    country: 'United Kingdom',
    region: 'Western Europe',
    category: 'Popular',
    rating: 4.8,
    shortDescription: 'Historic global capital spanning the Thames, royal palaces, world-class West End theatres, and free museums.',
    longDescription: 'Explore the British Museum, watch the changing of the guard at Buckingham Palace, ride the London Eye, and stroll through Soho and Covent Garden.',
    imageUrl: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 185,
    bestTimeToVisit: 'May - September',
    currentWeather: { temp: 16, condition: 'Mild Rain', icon: 'CloudRain' },
    topAttractions: [
      { name: 'Tower of London & Crown Jewels', description: 'Historic castle fortress with yeoman warders and royal armory.', estimatedCost: 35 },
      { name: 'British Museum', description: 'Dedicated to human history, art and culture, housing the Rosetta Stone.', estimatedCost: 0 },
      { name: 'London Eye & Thames Cruise', description: 'Giant observation wheel with 360-degree skyline views.', estimatedCost: 38 },
    ],
    travelTips: ['Contactless payment cards work directly at all Underground turnstiles.', 'Major state museums (British Museum, V&A, Tate) are completely free.'],
    safetyInfo: 'Safe city; watch your mobile phone around busy road crossings.',
    coordinates: { lat: 51.5074, lng: -0.1278 },
  },
  {
    id: 'dest-dubai',
    name: 'Dubai',
    country: 'United Arab Emirates',
    region: 'Middle East',
    category: 'Luxury',
    rating: 4.8,
    shortDescription: 'Futuristic desert metropolis of soaring skyscrapers, luxury shopping, and golden dune safaris.',
    longDescription: 'Marvel at Burj Khalifa, the worlds tallest building, shop in the Dubai Mall, cruise Dubai Marina, and experience dune bashing under starry Arabian skies.',
    imageUrl: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 220,
    bestTimeToVisit: 'November - March',
    currentWeather: { temp: 33, condition: 'Sunny & Warm', icon: 'Sun' },
    topAttractions: [
      { name: 'Burj Khalifa At The Top', description: 'Observation decks on levels 124 & 148 overlooking the Persian Gulf.', estimatedCost: 45 },
      { name: 'Desert Safari with BBQ Dinner', description: '4x4 dune bashing, camel rides, falconry, and traditional Tanoura dance.', estimatedCost: 55 },
      { name: 'Museum of the Future', description: 'Architectural wonder exploring future space technology and bio-design.', estimatedCost: 40 },
    ],
    travelTips: ['Dubai Metro is pristine and connects DXB airport directly to downtown.', 'Modest dress is respected in public malls and government buildings.'],
    safetyInfo: 'Extremely safe with virtually zero street crime.',
    coordinates: { lat: 25.2048, lng: 55.2708 },
  },
  {
    id: 'dest-banff',
    name: 'Banff & Canadian Rockies',
    country: 'Canada',
    region: 'Americas',
    category: 'Mountains',
    rating: 4.9,
    shortDescription: 'Glacial turquoise lakes like Lake Louise, towering alpine jagged peaks, and grizzly wildlife safaris.',
    longDescription: 'Canada’s first national park features the mesmerizing turquoise waters of Moraine Lake and Lake Louise, the Icefields Parkway drive, hot springs, and prime backcountry trails.',
    imageUrl: 'https://images.unsplash.com/photo-1503614472-8c93d56e92ce?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 195,
    bestTimeToVisit: 'June - September (Hiking & Lakes) or December - April (Skiing)',
    currentWeather: { temp: 12, condition: 'Crisp & Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Lake Louise & Plain of Six Glaciers', description: 'Iconic turquoise glacial lake with canoe rentals and alpine tea house hike.', estimatedCost: 15 },
      { name: 'Moraine Lake Valley of the Ten Peaks', description: 'Stunning azure lake in rugged glacier-carved valley.', estimatedCost: 0 },
      { name: 'Banff Gondola & Sulphur Mountain', description: '360-degree boardwalk summit view across six Canadian mountain ranges.', estimatedCost: 48 },
    ],
    travelTips: ['Parks Canada shuttles are required to reach Moraine Lake in peak season; reserve early.', 'Always carry bear spray on backcountry trails.'],
    safetyInfo: 'Very safe; keep a respectful 100m distance from bears and elk.',
    coordinates: { lat: 51.1784, lng: -115.5708 },
  },
  {
    id: 'dest-sydney',
    name: 'Sydney',
    country: 'Australia',
    region: 'Oceania',
    category: 'Popular',
    rating: 4.8,
    shortDescription: 'Sun-kissed harbor capital with iconic Opera House, Bondi coastal walks, and world-class coffee.',
    longDescription: 'Sydney combines dramatic coastal beauty with sparkling harbor living. Cruise past Sydney Harbour Bridge, surf at Bondi and Manly, and dine waterfront in Darling Harbour.',
    imageUrl: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 180,
    bestTimeToVisit: 'September - November & March - May',
    currentWeather: { temp: 22, condition: 'Sunny & Coastal Breeze', icon: 'Sun' },
    topAttractions: [
      { name: 'Sydney Opera House & Forecourt', description: 'Architectural sail masterpiece overlooking Sydney Harbour.', estimatedCost: 32 },
      { name: 'Bondi to Coogee Coastal Walk', description: 'Scenic 6km cliffside walking path past ocean pools and sandy coves.', estimatedCost: 0 },
      { name: 'Manly Ferry Harbor Crossing', description: 'Scenic public ferry ride crossing Sydney Heads past Harbour islands.', estimatedCost: 7 },
    ],
    travelTips: ['Use an Opal card or contactless payment card for all trains, buses, and ferries.', 'Apply 50+ SPF sunscreen even on overcast days.'],
    safetyInfo: 'Very safe global city; always swim between the red and yellow beach flags.',
    coordinates: { lat: -33.8688, lng: 151.2093 },
  },
  {
    id: 'dest-nyc',
    name: 'New York City',
    country: 'United States',
    region: 'Americas',
    category: 'Popular',
    rating: 4.9,
    shortDescription: 'The City That Never Sleeps featuring Broadway, Central Park, world-class museums, and iconic skyline.',
    longDescription: 'From the soaring summit of the Empire State Building to street food in Chinatown and sunset walks along the High Line elevated park, New York City provides unmatched metropolitan vitality.',
    imageUrl: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 240,
    bestTimeToVisit: 'April - June & September - November',
    currentWeather: { temp: 20, condition: 'Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Central Park & The Ramble', description: '843-acre urban sanctuary with Bethesda Terrace and Bow Bridge.', estimatedCost: 0 },
      { name: 'Metropolitan Museum of Art (The Met)', description: 'Worlds foremost art museum spanning 5,000 years of global culture.', estimatedCost: 30 },
      { name: 'High Line & Chelsea Market', description: '1.45-mile elevated rail line converted into green public garden trail.', estimatedCost: 0 },
    ],
    travelTips: ['The NYC Subway runs 24/7; tap to pay with OMNY contactless on your phone.', 'Walk across the Brooklyn Bridge towards Manhattan at golden hour.'],
    safetyInfo: 'Safe cosmopolitan city; stay aware of your surroundings late at night.',
    coordinates: { lat: 40.7128, lng: -74.006 },
  },
  {
    id: 'dest-cape-town',
    name: 'Cape Town',
    country: 'South Africa',
    region: 'Middle East',
    category: 'Adventure',
    rating: 4.8,
    shortDescription: 'Dramatic Table Mountain backdrop, Cape Point coastal drives, and Boulders Beach penguin colonies.',
    longDescription: 'Where the Atlantic and Indian Oceans meet beneath the flat-topped Table Mountain. Experience scenic Chapman’s Peak Drive, world-renowned Stellenbosch vineyards, and colorful Bo-Kaap houses.',
    imageUrl: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 95,
    bestTimeToVisit: 'November - March',
    currentWeather: { temp: 25, condition: 'Clear & Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Table Mountain Aerial Cableway', description: 'Revolving cable car climbing to flat mountain summit 1,067m above sea level.', estimatedCost: 22 },
      { name: 'Boulders Beach African Penguin Colony', description: 'Wooden boardwalks over sheltered coves filled with free-roaming wild penguins.', estimatedCost: 10 },
      { name: 'Chapmans Peak Drive to Cape Point', description: 'One of the worlds most dramatic marine cliffside coastal drives.', estimatedCost: 5 },
    ],
    travelTips: ['Book Table Mountain cableway tickets online and check wind conditions.', 'Use Uber for convenient point-to-point city transit.'],
    safetyInfo: 'Stick to established tourist corridors, beaches, and waterfront; avoid walking after dark alone.',
    coordinates: { lat: -33.9249, lng: 18.4241 },
  },
];

const CURRENCY_RATES = {
  USD: { code: 'USD', symbol: '$', name: 'US Dollar', rateAgainstUSD: 1.0 },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro', rateAgainstUSD: 0.92 },
  INR: { code: 'INR', symbol: '₹', name: 'Indian Rupee', rateAgainstUSD: 83.45 },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound', rateAgainstUSD: 0.79 },
  AED: { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', rateAgainstUSD: 3.67 },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen', rateAgainstUSD: 154.2 },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', rateAgainstUSD: 1.52 },
  CAD: { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', rateAgainstUSD: 1.36 },
  SGD: { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', rateAgainstUSD: 1.34 },
};

// -------------------------------------------------------------
// REST API ROUTES (Spring Boot REST API Parity)
// -------------------------------------------------------------

// Auth APIs
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  const user = USERS.find((u) => u.email.toLowerCase() === (email || '').toLowerCase()) || USERS[0];
  const token = `jwt_token_${user.id}_${Date.now()}`;
  res.json({
    success: true,
    message: 'Authentication successful',
    data: {
      user,
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: 86400,
    },
  });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { fullName, email, country, preferredCurrency, travelPreferences } = req.body;
  const newUser = {
    id: `usr-${Date.now()}`,
    fullName: fullName || 'New Traveler',
    email: email || `traveler${Date.now()}@tripnest.com`,
    avatarUrl: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
    country: country || 'United States',
    preferredCurrency: preferredCurrency || 'USD',
    travelPreferences: travelPreferences || ['Sightseeing', 'Food'],
    role: 'TRAVELER',
    createdAt: new Date().toISOString(),
  };
  USERS.push(newUser);
  const token = `jwt_token_${newUser.id}_${Date.now()}`;
  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    data: {
      user: newUser,
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: 86400,
    },
  });
});

app.post('/api/auth/google', (req: Request, res: Response) => {
  const { email, fullName, avatarUrl } = req.body || {};
  const userEmail = email || 'madhugorla497@gmail.com';
  let existingUser = USERS.find((u) => u.email.toLowerCase() === userEmail.toLowerCase());
  let targetUser: ServerUser;
  if (!existingUser) {
    targetUser = {
      id: `usr-google-${Date.now()}`,
      fullName: fullName || (userEmail.startsWith('madhugorla') ? 'Madhu Gorla' : userEmail.split('@')[0]),
      email: userEmail,
      avatarUrl: avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      country: 'India',
      preferredCurrency: 'INR',
      travelPreferences: ['Adventure', 'Historical', 'Culture'],
      role: 'TRAVELER',
      isGoogleUser: true,
      provider: 'google',
      createdAt: new Date().toISOString(),
    };
    USERS.push(targetUser);
  } else {
    existingUser.isGoogleUser = true;
    existingUser.provider = 'google';
    if (fullName) existingUser.fullName = fullName;
    if (avatarUrl) existingUser.avatarUrl = avatarUrl;
    targetUser = existingUser;
  }
  const token = `jwt_google_${targetUser.id}_${Date.now()}`;
  res.json({
    success: true,
    message: 'Google authentication successful',
    data: {
      user: targetUser,
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: 86400,
    },
  });
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.json({ success: true, data: USERS[0] });
  }
  const token = authHeader.replace('Bearer ', '');
  const matchedUser = USERS.find((u) => token.includes(u.id));
  res.json({
    success: true,
    data: matchedUser || USERS[0],
  });
});

// Zip Download Endpoint for project source code
app.get(['/api/download-zip', '/download-zip'], (req: Request, res: Response) => {
  const zipPath = path.resolve(process.cwd(), 'public', 'tripnest-complete-code.zip');
  res.download(zipPath, 'tripnest-complete-code.zip', (err) => {
    if (err) {
      res.status(500).json({ success: false, message: 'Failed to download zip file' });
    }
  });
});

// Trips APIs
app.get('/api/trips', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: TRIPS,
  });
});

app.get('/api/trips/upcoming', (req: Request, res: Response) => {
  const upcoming = TRIPS.filter((t) => t.status === 'UPCOMING' || t.status === 'PLANNING');
  res.json({
    success: true,
    data: upcoming,
  });
});

app.get('/api/trips/past', (req: Request, res: Response) => {
  const past = TRIPS.filter((t) => t.status === 'COMPLETED');
  res.json({
    success: true,
    data: past,
  });
});

app.get('/api/trips/:id', (req: Request, res: Response) => {
  const trip = TRIPS.find((t) => t.id === req.params.id);
  if (!trip) {
    return res.status(404).json({ success: false, message: 'Trip not found' });
  }
  res.json({ success: true, data: trip });
});

app.post('/api/trips', (req: Request, res: Response) => {
  const { tripName, description, destination, country, startDate, endDate, travelers, budget, currency, travelStyle, coverImage } = req.body;
  
  // Find destination coordinates if available
  const matchDest = DESTINATIONS.find((d) => d.name.toLowerCase() === (destination || '').toLowerCase());
  const coords = matchDest ? matchDest.coordinates : { lat: 41.9028, lng: 12.4964 };
  const fallbackImg = matchDest ? matchDest.imageUrl : '/src/assets/images/hero_travel_workspace_1790172750348.jpg';

  const newTrip = {
    id: `trip-${Date.now()}`,
    tripName: tripName || 'New Adventure',
    description: description || `Exploring ${destination}`,
    destination: destination || 'Rome',
    country: country || (matchDest ? matchDest.country : 'Italy'),
    startDate: startDate || new Date().toISOString().split('T')[0],
    endDate: endDate || new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
    travelers: travelers ? parseInt(travelers) : 1,
    budget: budget ? parseFloat(budget) : 2000,
    spent: 0,
    currency: currency || 'USD',
    status: 'PLANNING',
    visibility: 'PRIVATE',
    coverImage: coverImage || fallbackImg,
    ownerId: 'usr-1',
    ownerName: 'Lara Croft',
    travelStyle: travelStyle || 'Standard',
    coordinates: coords,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  TRIPS.unshift(newTrip);

  // Generate initial Day 1 itinerary container
  const newDay = {
    id: `day-${Date.now()}-1`,
    tripId: newTrip.id,
    dayNumber: 1,
    date: newTrip.startDate,
    title: 'Arrival & Welcome',
    summary: `Arrive in ${newTrip.destination}, settle in, and explore the city center.`,
    activities: [
      {
        id: `act-${Date.now()}-1`,
        dayId: `day-${Date.now()}-1`,
        tripId: newTrip.id,
        name: `Arrive in ${newTrip.destination}`,
        description: 'Check in to accommodation and relax after journey.',
        startTime: '12:00',
        endTime: '14:00',
        location: `${newTrip.destination} Center`,
        category: 'Hotel',
        cost: 0,
        currency: newTrip.currency,
        priority: 'High',
        isCompleted: false,
        coordinates: coords,
      },
    ],
  };
  ITINERARY_DAYS.push(newDay);

  res.status(201).json({
    success: true,
    message: 'Trip created successfully',
    data: newTrip,
  });
});

app.put('/api/trips/:id', (req: Request, res: Response) => {
  const index = TRIPS.findIndex((t) => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Trip not found' });
  }
  TRIPS[index] = {
    ...TRIPS[index],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  res.json({
    success: true,
    message: 'Trip updated successfully',
    data: TRIPS[index],
  });
});

app.delete('/api/trips/:id', (req: Request, res: Response) => {
  TRIPS = TRIPS.filter((t) => t.id !== req.params.id);
  ITINERARY_DAYS = ITINERARY_DAYS.filter((d) => d.tripId !== req.params.id);
  EXPENSES = EXPENSES.filter((e) => e.tripId !== req.params.id);
  res.json({
    success: true,
    message: 'Trip deleted successfully',
  });
});

// Itineraries & Activities APIs
app.get('/api/itineraries/trip/:tripId', (req: Request, res: Response) => {
  const days = ITINERARY_DAYS.filter((d) => d.tripId === req.params.tripId);
  res.json({
    success: true,
    data: days,
  });
});

app.post('/api/itineraries', (req: Request, res: Response) => {
  const { tripId, dayNumber, date, title, summary } = req.body;
  const newDay = {
    id: `day-${Date.now()}`,
    tripId,
    dayNumber: dayNumber || 1,
    date: date || new Date().toISOString().split('T')[0],
    title: title || `Day ${dayNumber}`,
    summary: summary || 'Planned exploration and leisure.',
    activities: [],
  };
  ITINERARY_DAYS.push(newDay);
  res.status(201).json({
    success: true,
    message: 'Itinerary day added successfully',
    data: newDay,
  });
});

app.post('/api/activities', (req: Request, res: Response) => {
  const { dayId, tripId, name, description, startTime, endTime, location, category, cost, currency, notes, priority, coordinates } = req.body;
  const day = ITINERARY_DAYS.find((d) => d.id === dayId);
  if (!day) {
    return res.status(404).json({ success: false, message: 'Itinerary day not found' });
  }

  const newActivity = {
    id: `act-${Date.now()}`,
    dayId,
    tripId,
    name: name || 'New Activity',
    description: description || '',
    startTime: startTime || '10:00',
    endTime: endTime || '12:00',
    location: location || 'City Landmark',
    category: category || 'Sightseeing',
    cost: cost ? parseFloat(cost) : 0,
    currency: currency || 'USD',
    notes: notes || '',
    priority: priority || 'Medium',
    isCompleted: false,
    coordinates: coordinates || { lat: 41.8902, lng: 12.4922 },
  };

  day.activities.push(newActivity);
  res.status(201).json({
    success: true,
    message: 'Activity created successfully',
    data: newActivity,
  });
});

app.put('/api/activities/:id', (req: Request, res: Response) => {
  let found = false;
  for (const day of ITINERARY_DAYS) {
    const actIndex = day.activities.findIndex((a) => a.id === req.params.id);
    if (actIndex !== -1) {
      day.activities[actIndex] = { ...day.activities[actIndex], ...req.body };
      found = true;
      return res.json({ success: true, message: 'Activity updated', data: day.activities[actIndex] });
    }
  }
  if (!found) {
    res.status(404).json({ success: false, message: 'Activity not found' });
  }
});

app.delete('/api/activities/:id', (req: Request, res: Response) => {
  for (const day of ITINERARY_DAYS) {
    day.activities = day.activities.filter((a) => a.id !== req.params.id);
  }
  res.json({ success: true, message: 'Activity deleted' });
});

app.patch('/api/activities/:id/toggle', (req: Request, res: Response) => {
  for (const day of ITINERARY_DAYS) {
    const act = day.activities.find((a) => a.id === req.params.id);
    if (act) {
      act.isCompleted = !act.isCompleted;
      return res.json({ success: true, data: act });
    }
  }
  res.status(404).json({ success: false, message: 'Activity not found' });
});

// Expenses & Budget APIs
app.get('/api/expenses/trip/:tripId', (req: Request, res: Response) => {
  const expenses = EXPENSES.filter((e) => e.tripId === req.params.tripId);
  res.json({ success: true, data: expenses });
});

app.post('/api/expenses', (req: Request, res: Response) => {
  const { tripId, title, amount, currency, category, date, paidById, paidByName, paymentMethod, notes, splits } = req.body;
  const numAmount = parseFloat(amount) || 0;
  const newExpense = {
    id: `exp-${Date.now()}`,
    tripId,
    title: title || 'Expense',
    amount: numAmount,
    currency: currency || 'USD',
    category: category || 'Other',
    date: date || new Date().toISOString().split('T')[0],
    paidById: paidById || 'usr-1',
    paidByName: paidByName || 'Lara Croft',
    paymentMethod: paymentMethod || 'Credit Card',
    notes: notes || '',
    splits: splits || [
      { userId: 'usr-1', userName: 'Lara Croft', amount: numAmount / 2, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: numAmount / 2, settled: false },
    ],
  };

  EXPENSES.unshift(newExpense);

  // Update Trip spent amount
  const trip = TRIPS.find((t) => t.id === tripId);
  if (trip) {
    trip.spent = (trip.spent || 0) + numAmount;
  }

  res.status(201).json({
    success: true,
    message: 'Expense added successfully',
    data: newExpense,
  });
});

app.delete('/api/expenses/:id', (req: Request, res: Response) => {
  const exp = EXPENSES.find((e) => e.id === req.params.id);
  if (exp) {
    const trip = TRIPS.find((t) => t.id === exp.tripId);
    if (trip) {
      trip.spent = Math.max(0, (trip.spent || 0) - exp.amount);
    }
  }
  EXPENSES = EXPENSES.filter((e) => e.id !== req.params.id);
  res.json({ success: true, message: 'Expense deleted successfully' });
});

// Settlements calculation (who owes whom)
app.get('/api/expenses/settlements/:tripId', (req: Request, res: Response) => {
  const expenses = EXPENSES.filter((e) => e.tripId === req.params.tripId);
  const balances: Record<string, number> = {};

  for (const exp of expenses) {
    balances[exp.paidByName] = (balances[exp.paidByName] || 0) + exp.amount;
    for (const split of exp.splits) {
      balances[split.userName] = (balances[split.userName] || 0) - split.amount;
    }
  }

  const debtors: { name: string; amount: number }[] = [];
  const creditors: { name: string; amount: number }[] = [];

  for (const [name, balance] of Object.entries(balances)) {
    if (balance < -0.01) {
      debtors.push({ name, amount: -balance });
    } else if (balance > 0.01) {
      creditors.push({ name, amount: balance });
    }
  }

  const settlements: any[] = [];
  let dIdx = 0;
  let cIdx = 0;

  while (dIdx < debtors.length && cIdx < creditors.length) {
    const debtor = debtors[dIdx];
    const creditor = creditors[cIdx];
    const settleAmt = Math.min(debtor.amount, creditor.amount);

    settlements.push({
      fromUser: debtor.name,
      toUser: creditor.name,
      amount: Math.round(settleAmt * 100) / 100,
      currency: expenses[0]?.currency || 'USD',
    });

    debtor.amount -= settleAmt;
    creditor.amount -= settleAmt;

    if (debtor.amount < 0.01) dIdx++;
    if (creditor.amount < 0.01) cIdx++;
  }

  res.json({ success: true, data: settlements, balances });
});

// Destinations APIs
app.get('/api/destinations', (req: Request, res: Response) => {
  const { category, search, region } = req.query;
  let filtered = [...DESTINATIONS];
  if (category && category !== 'All') {
    filtered = filtered.filter((d) => d.category.toLowerCase() === String(category).toLowerCase());
  }
  if (region && region !== 'All') {
    const reg = String(region).toLowerCase();
    if (reg === 'india') {
      filtered = filtered.filter((d) => d.country.toLowerCase() === 'india');
    } else if (reg === 'international') {
      filtered = filtered.filter((d) => d.country.toLowerCase() !== 'india');
    } else {
      filtered = filtered.filter(
        (d) =>
          d.region.toLowerCase().includes(reg) ||
          d.country.toLowerCase().includes(reg)
      );
    }
  }
  if (search) {
    const q = String(search).toLowerCase();
    filtered = filtered.filter(
      (d) =>
        d.name.toLowerCase().includes(q) ||
        d.country.toLowerCase().includes(q) ||
        d.region.toLowerCase().includes(q) ||
        d.shortDescription.toLowerCase().includes(q) ||
        d.category.toLowerCase().includes(q)
    );
  }
  res.json({ success: true, data: filtered });
});

app.get('/api/destinations/:id', (req: Request, res: Response) => {
  const dest = DESTINATIONS.find((d) => d.id === req.params.id);
  if (!dest) {
    return res.status(404).json({ success: false, message: 'Destination not found' });
  }
  res.json({ success: true, data: dest });
});

// Groups APIs
app.get('/api/groups', (req: Request, res: Response) => {
  res.json({ success: true, data: GROUPS });
});

app.get('/api/groups/trip/:tripId', (req: Request, res: Response) => {
  const grp = GROUPS.find((g) => g.tripId === req.params.tripId);
  res.json({ success: true, data: grp || null });
});

app.post('/api/groups/:id/invite', (req: Request, res: Response) => {
  const { email, role } = req.body;
  const grp = GROUPS.find((g) => g.id === req.params.id);
  if (!grp) {
    return res.status(404).json({ success: false, message: 'Group not found' });
  }
  const newMember = {
    userId: `usr-${Date.now()}`,
    name: email.split('@')[0],
    email,
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    role: role || 'Member',
    joinedAt: new Date().toISOString(),
  };
  grp.members.push(newMember);
  res.json({ success: true, message: `Invitation sent to ${email}`, data: grp });
});

// Documents APIs
app.get('/api/documents/trip/:tripId', (req: Request, res: Response) => {
  const docs = DOCUMENTS.filter((d) => d.tripId === req.params.tripId);
  res.json({ success: true, data: docs });
});

app.post('/api/documents', (req: Request, res: Response) => {
  const { tripId, name, category, fileSize, expiryDate, notes } = req.body;
  const newDoc = {
    id: `doc-${Date.now()}`,
    tripId,
    name: name || 'Document.pdf',
    category: category || 'Other',
    fileSize: fileSize || '1.2 MB',
    fileType: 'application/pdf',
    uploadDate: new Date().toISOString().split('T')[0],
    expiryDate: expiryDate || undefined,
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: notes || '',
  };
  DOCUMENTS.push(newDoc);
  res.status(201).json({ success: true, message: 'Document uploaded securely', data: newDoc });
});

app.delete('/api/documents/:id', (req: Request, res: Response) => {
  DOCUMENTS = DOCUMENTS.filter((d) => d.id !== req.params.id);
  res.json({ success: true, message: 'Document deleted successfully' });
});

// Notifications APIs
app.get('/api/notifications', (req: Request, res: Response) => {
  res.json({ success: true, data: NOTIFICATIONS });
});

app.patch('/api/notifications/:id/read', (req: Request, res: Response) => {
  const notif = NOTIFICATIONS.find((n) => n.id === req.params.id);
  if (notif) notif.isRead = true;
  res.json({ success: true, data: notif });
});

app.post('/api/notifications/read-all', (req: Request, res: Response) => {
  NOTIFICATIONS.forEach((n) => (n.isRead = true));
  res.json({ success: true, message: 'All notifications marked as read' });
});

// Favorites APIs
app.get('/api/favorites', (req: Request, res: Response) => {
  const favDestinations = DESTINATIONS.filter((d) => FAVORITES.includes(d.id));
  res.json({ success: true, data: favDestinations });
});

app.post('/api/favorites/toggle', (req: Request, res: Response) => {
  const { destinationId } = req.body;
  if (FAVORITES.includes(destinationId)) {
    FAVORITES = FAVORITES.filter((id) => id !== destinationId);
    return res.json({ success: true, isFavorited: false, message: 'Removed from favorites' });
  } else {
    FAVORITES.push(destinationId);
    return res.json({ success: true, isFavorited: true, message: 'Saved to favorites' });
  }
});

// Currency & Weather APIs
app.get('/api/currency/rates', (req: Request, res: Response) => {
  res.json({ success: true, data: CURRENCY_RATES });
});

// Helper function to map WMO weather code to condition and icon
function mapWmoWeatherCode(code: number): { condition: string; icon: string } {
  if (code === 0) return { condition: 'Clear Sky', icon: 'Sun' };
  if (code === 1 || code === 2) return { condition: 'Partly Cloudy', icon: 'CloudSun' };
  if (code === 3) return { condition: 'Overcast', icon: 'Cloud' };
  if (code === 45 || code === 48) return { condition: 'Foggy', icon: 'CloudFog' };
  if (code >= 51 && code <= 55) return { condition: 'Light Drizzle', icon: 'CloudDrizzle' };
  if ((code >= 61 && code <= 65) || (code >= 80 && code <= 82)) return { condition: 'Rain Showers', icon: 'CloudRain' };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { condition: 'Snowfall', icon: 'CloudSnow' };
  if (code >= 95 && code <= 99) return { condition: 'Thunderstorm', icon: 'CloudLightning' };
  return { condition: 'Partly Cloudy', icon: 'CloudSun' };
}

function generatePackingTip(tempMax: number, tempMin: number, precipProb: number, uvIndex: number): string {
  if (precipProb > 45) return 'Rain expected — pack a compact umbrella and water-resistant shoes.';
  if (uvIndex >= 6) return 'High UV exposure — carry SPF 50+ sunscreen, a sun hat, and UV-protective shades.';
  if (tempMax >= 30) return 'Tropical warmth — wear breathable linen or cotton, and keep a refillable water bottle.';
  if (tempMin <= 8) return 'Crisp chill in the morning/evening — layer with a fleece jacket and light scarf.';
  if (tempMax >= 22 && tempMin >= 14) return 'Ideal sightseeing weather — comfortable walking sneakers and casual layers recommended.';
  return 'Mild conditions — light layer for evening breezes and comfortable walking shoes.';
}

app.get('/api/weather/:city', async (req: Request, res: Response) => {
  const city = req.params.city || 'Rome';
  const match = DESTINATIONS.find((d) => d.name.toLowerCase() === city.toLowerCase() || city.toLowerCase().includes(d.name.toLowerCase()));
  
  let lat = match?.coordinates?.lat || 41.9028;
  let lng = match?.coordinates?.lng || 12.4964;

  // Try live Open-Meteo real-time forecast
  try {
    // If not matched directly in DESTINATIONS, perform quick geocode
    if (!match?.coordinates) {
      try {
        const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`, {
          signal: AbortSignal.timeout(2500),
        });
        if (geoRes.ok) {
          const geoData = (await geoRes.json()) as any;
          if (geoData.results && geoData.results[0]) {
            lat = geoData.results[0].latitude;
            lng = geoData.results[0].longitude;
          }
        }
      } catch (e) {
        // Fall back to default coordinates
      }
    }

    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&daily=weathercode,temperature_2m_max,temperature_2m_min,precipitation_probability_max,windspeed_10m_max,uv_index_max&current_weather=true&timezone=auto`;
    const liveRes = await fetch(weatherUrl, { signal: AbortSignal.timeout(3000) });

    if (liveRes.ok) {
      const liveData = (await liveRes.json()) as any;
      const current = liveData.current_weather;
      const daily = liveData.daily;

      const currentMapped = mapWmoWeatherCode(current.weathercode);
      const forecastDays = [];
      const dayNames = ['Today', 'Tomorrow', 'Day 3', 'Day 4', 'Day 5'];

      const totalDays = Math.min(5, (daily.time || []).length);
      for (let i = 0; i < totalDays; i++) {
        const dateStr = daily.time[i];
        const dateObj = new Date(dateStr);
        const dayLabel = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : dateObj.toLocaleDateString('en-US', { weekday: 'short' });
        const formattedDate = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const maxT = Math.round(daily.temperature_2m_max[i]);
        const minT = Math.round(daily.temperature_2m_min[i]);
        const avgT = Math.round((maxT + minT) / 2);
        const precip = daily.precipitation_probability_max ? Math.round(daily.precipitation_probability_max[i] || 0) : 10;
        const wind = daily.windspeed_10m_max ? `${Math.round(daily.windspeed_10m_max[i])} km/h` : `${Math.round(current.windspeed)} km/h`;
        const uv = daily.uv_index_max ? Math.round(daily.uv_index_max[i] * 10) / 10 : 5.0;
        const mapped = mapWmoWeatherCode(daily.weathercode[i]);

        forecastDays.push({
          day: dayLabel,
          date: formattedDate,
          temp: avgT,
          tempMin: minT,
          tempMax: maxT,
          condition: mapped.condition,
          humidity: Math.max(35, Math.min(90, 60 + (i % 3) * 5)),
          icon: mapped.icon,
          precipitationChance: precip,
          windSpeed: wind,
          uvIndex: uv,
          packingTip: generatePackingTip(maxT, minT, precip, uv),
        });
      }

      return res.json({
        success: true,
        data: {
          city: match?.name || city,
          currentTemp: Math.round(current.temperature),
          condition: currentMapped.condition,
          humidity: 58,
          windSpeed: `${Math.round(current.windspeed)} km/h`,
          icon: currentMapped.icon,
          uvIndex: forecastDays[0]?.uvIndex || 5.2,
          precipitationChance: forecastDays[0]?.precipitationChance || 10,
          isRealtime: true,
          timezone: liveData.timezone || 'UTC',
          lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          forecast: forecastDays,
        },
      });
    }
  } catch (err) {
    console.warn('Real-time weather fetch failed, using realistic fallback:', err);
  }

  // Graceful fallback if external weather service times out
  const baseTemp = match ? match.currentWeather.temp : 24;
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const todayIndex = new Date().getDay();

  const fallbackForecast = [
    { day: 'Today', date: 'Day 1', temp: baseTemp, tempMin: baseTemp - 5, tempMax: baseTemp + 3, condition: match?.currentWeather?.condition || 'Sunny & Clear', humidity: 55, icon: 'Sun', precipitationChance: 10, windSpeed: '12 km/h', uvIndex: 6.2, packingTip: 'Ideal sightseeing weather — comfortable walking sneakers and sunglasses recommended.' },
    { day: 'Tomorrow', date: 'Day 2', temp: baseTemp + 1, tempMin: baseTemp - 4, tempMax: baseTemp + 4, condition: 'Partly Cloudy', humidity: 58, icon: 'CloudSun', precipitationChance: 15, windSpeed: '14 km/h', uvIndex: 5.8, packingTip: 'Pleasant daytime breeze — light jacket suitable for evening dining.' },
    { day: daysOfWeek[(todayIndex + 2) % 7], date: 'Day 3', temp: baseTemp - 1, tempMin: baseTemp - 5, tempMax: baseTemp + 2, condition: 'Mild Breeze', humidity: 62, icon: 'CloudSun', precipitationChance: 25, windSpeed: '16 km/h', uvIndex: 5.0, packingTip: 'Great outdoor walking climate — stay hydrated and keep camera ready.' },
    { day: daysOfWeek[(todayIndex + 3) % 7], date: 'Day 4', temp: baseTemp + 2, tempMin: baseTemp - 3, tempMax: baseTemp + 5, condition: 'Clear Sky', humidity: 50, icon: 'Sun', precipitationChance: 5, windSpeed: '10 km/h', uvIndex: 6.5, packingTip: 'Warm and sunny afternoon — pack SPF 50+ sunscreen and a sun hat.' },
    { day: daysOfWeek[(todayIndex + 4) % 7], date: 'Day 5', temp: baseTemp, tempMin: baseTemp - 4, tempMax: baseTemp + 3, condition: 'Scattered Clouds', humidity: 64, icon: 'Cloud', precipitationChance: 20, windSpeed: '13 km/h', uvIndex: 5.2, packingTip: 'Perfect conditions for historical tours and museum visits.' },
  ];

  res.json({
    success: true,
    data: {
      city: match?.name || city,
      currentTemp: baseTemp,
      condition: match ? match.currentWeather.condition : 'Partly Cloudy',
      humidity: 58,
      windSpeed: '12 km/h',
      icon: match ? match.currentWeather.icon : 'Sun',
      uvIndex: 6.2,
      precipitationChance: 10,
      isRealtime: false,
      lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      forecast: fallbackForecast,
    },
  });
});

// Analytics APIs
app.get('/api/analytics/traveler', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      totalTrips: TRIPS.length,
      countriesVisited: 3,
      favoriteDestination: 'Rome',
      averageTripCost: 2800,
      totalSpending: TRIPS.reduce((acc, t) => acc + (t.spent || 0), 0),
      averageTripDuration: '5.2 Days',
      expensesByCategory: [
        { category: 'Flights', amount: 1450, percentage: 38 },
        { category: 'Accommodation', amount: 1200, percentage: 31 },
        { category: 'Food', amount: 480, percentage: 13 },
        { category: 'Activities', amount: 420, percentage: 11 },
        { category: 'Transportation', amount: 250, percentage: 7 },
      ],
      monthlyTrips: [
        { month: 'Jun', count: 1 },
        { month: 'Jul', count: 2 },
        { month: 'Aug', count: 1 },
        { month: 'Sep', count: 0 },
        { month: 'Oct', count: 2 },
        { month: 'Nov', count: 1 },
      ],
    },
  });
});

app.get('/api/analytics/admin', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      totalUsers: 1420,
      activeUsers: 840,
      totalTripsCreated: 3120,
      activeTrips: 185,
      totalExpensesLogged: 124500,
      topDestinations: [
        { name: 'Rome', tripsCount: 420 },
        { name: 'Bali', tripsCount: 380 },
        { name: 'Goa', tripsCount: 310 },
        { name: 'Paris', tripsCount: 290 },
        { name: 'Tokyo', tripsCount: 260 },
      ],
      recentUsers: USERS,
    },
  });
});

// Reports APIs
app.get('/api/reports/trip/:id', (req: Request, res: Response) => {
  const trip = TRIPS.find((t) => t.id === req.params.id);
  const itinerary = ITINERARY_DAYS.filter((d) => d.tripId === req.params.id);
  const expenses = EXPENSES.filter((e) => e.tripId === req.params.id);
  res.json({
    success: true,
    data: {
      trip,
      itinerary,
      expenses,
      generatedAt: new Date().toISOString(),
      summary: {
        totalDays: itinerary.length,
        totalActivities: itinerary.reduce((acc, d) => acc + d.activities.length, 0),
        totalExpenses: expenses.reduce((acc, e) => acc + e.amount, 0),
        budgetStatus: (trip?.spent || 0) <= (trip?.budget || 0) ? 'Within Budget' : 'Over Budget',
      },
    },
  });
});

// -------------------------------------------------------------
// AI COPILOT SERVICE (Google GenAI gemini-3.8-flash)
// -------------------------------------------------------------

app.post('/api/ai/chat', async (req: Request, res: Response) => {
  const { message, tripId, conversationHistory } = req.body;
  const currentTrip = TRIPS.find((t) => t.id === tripId) || TRIPS[0];
  const tripItinerary = ITINERARY_DAYS.filter((d) => d.tripId === currentTrip.id);
  const tripExpenses = EXPENSES.filter((e) => e.tripId === currentTrip.id);

  // If Gemini API client is available, call gemini-3.8-flash
  if (aiClient) {
    try {
      const prompt = `You are TripNest AI, an elite, friendly, and practical AI travel copilot.
Context about the current trip:
- Trip Name: ${currentTrip.tripName}
- Destination: ${currentTrip.destination}, ${currentTrip.country}
- Dates: ${currentTrip.startDate} to ${currentTrip.endDate}
- Travelers: ${currentTrip.travelers}
- Budget: ${currentTrip.currency} ${currentTrip.budget}
- Current Spent: ${currentTrip.currency} ${currentTrip.spent}
- Travel Style: ${currentTrip.travelStyle}
- Current Itinerary: ${JSON.stringify(
        tripItinerary.map((d) => ({
          day: d.dayNumber,
          title: d.title,
          activities: d.activities.map((a) => `${a.startTime} - ${a.name} (${a.category}, ${currentTrip.currency} ${a.cost})`),
        }))
      )}
- Logged Expenses: ${JSON.stringify(tripExpenses.map((e) => `${e.title}: ${currentTrip.currency} ${e.amount} (${e.category})`))}

User query: "${message}"

Respond with high quality, specific travel advice.
Format your response as a valid JSON object matching this structure:
{
  "reply": "Your clear, formatted message to the traveler (markdown allowed)",
  "actions": [
    {
      "id": "act-proposal-1",
      "type": "ADD_ACTIVITY" | "OPTIMIZE_BUDGET" | "REARRANGE_ITINERARY" | "GENERATE_PACKING_LIST",
      "label": "Short button label, e.g. Add Trastevere Food Tour",
      "description": "Short explanation of the proposed change",
      "payload": {}
    }
  ]
}
If no explicit action is needed, return empty actions array. Return ONLY raw JSON without markdown code fences.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      let jsonText = response.text || '';
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      const parsed = JSON.parse(jsonText);
      return res.json({
        success: true,
        data: {
          reply: parsed.reply,
          actions: parsed.actions || [],
        },
      });
    } catch (err) {
      console.warn('Gemini API call fallback to intelligent engine:', err);
    }
  }

  // Intelligent domain-grounded fallback if Gemini API is offline or key missing
  const lowerMsg = (message || '').toLowerCase();
  let reply = '';
  const actions: any[] = [];

  if (lowerMsg.includes('budget') || lowerMsg.includes('cheaper') || lowerMsg.includes('cost') || lowerMsg.includes('save')) {
    reply = `Based on your budget of **${currentTrip.currency} ${currentTrip.budget}** and current spend of **${currentTrip.currency} ${currentTrip.spent}** for ${currentTrip.destination}:\n\n` +
      `1. **Accommodation**: Your hotel takes up ~45% of total budget. Booking an authorized boutique guesthouse in Monti or Trastevere can save ~$350.\n` +
      `2. **Dining**: Dine at family-run *osterie* on side streets rather than piazza fronts (savings: 30-40% per meal).\n` +
      `3. **Transport**: Use transit passes (Roma Pass or Metro passes) instead of taxis.`;
    actions.push({
      id: `opt-${Date.now()}`,
      type: 'OPTIMIZE_BUDGET',
      label: 'Apply 15% Budget Optimization',
      description: 'Shifts projected dining and transport estimates down to reflect local recommendations.',
      payload: { targetSavingsPercentage: 15 },
    });
  } else if (lowerMsg.includes('itinerary') || lowerMsg.includes('plan') || lowerMsg.includes('day')) {
    reply = `Here is a curated itinerary optimization for **${currentTrip.destination}**:\n\n` +
      `• **Day 1**: Arrival, check-in, Colosseum & Roman Forum VIP access, sunset dinner at Trattoria Monti.\n` +
      `• **Day 2**: Vatican Museums early access (08:30), St. Peter's Dome climb, evening stroll & natural wine in Trastevere.\n` +
      `• **Day 3**: Trevi Fountain early toss, Spanish Steps, bicycle rental in Villa Borghese gardens.\n\n` +
      `All locations have been clustered by proximity to minimize walking and transit delays.`;
    actions.push({
      id: `act-${Date.now()}`,
      type: 'ADD_ACTIVITY',
      label: 'Add Secret Food Walk to Day 2',
      description: 'Adds an evening 2-hour guided artisan gelato and pizza tasting in Trastevere.',
      payload: {
        dayNumber: 2,
        name: 'Trastevere Artisan Food & Gelato Walk',
        description: 'Taste authentic supplì, trapizzino, and artisanal pistachio gelato.',
        startTime: '17:30',
        endTime: '19:30',
        location: 'Trastevere Piazza, Rome',
        category: 'Food',
        cost: 45,
        priority: 'High',
      },
    });
  } else if (lowerMsg.includes('pack') || lowerMsg.includes('packing')) {
    reply = `Here is your customized packing checklist for **${currentTrip.destination}** in ${currentTrip.startDate.split('-')[1]} (Average 22-26°C):\n\n` +
      `🎒 **Essential Documents**: Passport, Schengen Visa copy, hotel reservations, international travel insurance card.\n` +
      `👟 **Footwear**: Broken-in walking sneakers with arch support (Rome has uneven basalt cobblestones).\n` +
      `👗 **Attire**: Breathable layers, lightweight cardigan for evenings, modest scarf/shawl for entering sacred churches.\n` +
      `🔌 **Electronics**: European Type C/F plug adapters, 10,000mAh power bank for all-day navigation.`;
    actions.push({
      id: `pack-${Date.now()}`,
      type: 'GENERATE_PACKING_LIST',
      label: 'Save Packing Checklist to Trip Notes',
      description: 'Embeds this structured packing list into your trip workspace.',
      payload: { destination: currentTrip.destination },
    });
  } else {
    reply = `I am your **TripNest AI Copilot** for **${currentTrip.destination}**! I have full visibility into your ${currentTrip.travelers}-person itinerary, budget (${currentTrip.currency} ${currentTrip.budget}), and booked activities.\n\n` +
      `I can help you with:\n` +
      `• **Build or reorder day-wise itineraries** based on geography\n` +
      `• **Optimize spending & find hidden savings**\n` +
      `• **Suggest authentic dining & attractions**\n` +
      `• **Generate dynamic packing lists** based on local weather`;
  }

  res.json({
    success: true,
    data: {
      reply,
      actions,
    },
  });
});

app.post('/api/ai/plan-trip', async (req: Request, res: Response) => {
  const { destination, days = 4, budget, currency = 'USD', travelStyle = 'Standard', travelers = 2 } = req.body;

  if (aiClient) {
    try {
      const prompt = `Generate a realistic, detailed ${days}-day travel itinerary for ${travelers} travelers visiting ${destination}.
Travel style: ${travelStyle}. Budget: ${currency} ${budget}.
Return a strict JSON object with this exact shape:
{
  "tripName": "${destination} Highlights & Culture",
  "description": "Curated ${days}-day journey through ${destination}",
  "days": [
    {
      "dayNumber": 1,
      "title": "Day 1 Title",
      "summary": "Day 1 summary",
      "activities": [
        {
          "name": "Activity Name",
          "description": "Description",
          "startTime": "09:00",
          "endTime": "11:00",
          "location": "Specific location in ${destination}",
          "category": "Sightseeing",
          "cost": 25,
          "priority": "High"
        }
      ]
    }
  ]
}
Return ONLY valid JSON.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      let jsonText = response.text || '';
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      const parsed = JSON.parse(jsonText);
      return res.json({ success: true, data: parsed });
    } catch (err) {
      console.warn('AI Plan Trip fallback:', err);
    }
  }

  // Pre-crafted high-fidelity itinerary template for quick fallback
  const generatedPlan = {
    tripName: `${destination} Grand Experience`,
    description: `A masterfully balanced ${days}-day itinerary covering historic wonders, local dining, and relaxing evening sights in ${destination}.`,
    days: Array.from({ length: Math.min(days, 5) }, (_, i) => ({
      dayNumber: i + 1,
      title: i === 0 ? 'Arrival & Historic Landmarks' : i === 1 ? 'Cultural Immersion & Art' : i === 2 ? 'Local Gastronomy & Scenic Views' : `Day ${i + 1} Hidden Gems & Leisure`,
      summary: `Day ${i + 1} in ${destination} focusing on top landmarks and authentic culinary experiences.`,
      activities: [
        {
          name: `Morning Highlights in ${destination}`,
          description: 'Explore the most celebrated historical landmark with early access.',
          startTime: '09:30',
          endTime: '12:00',
          location: `${destination} Central District`,
          category: 'Sightseeing',
          cost: 35,
          priority: 'High',
        },
        {
          name: 'Artisan Lunch & Food Market',
          description: 'Sample local specialties and fresh seasonal dishes at the central food market.',
          startTime: '12:30',
          endTime: '14:00',
          location: `${destination} Market Square`,
          category: 'Food',
          cost: 25,
          priority: 'Medium',
        },
        {
          name: 'Scenic Sunset Walk & Viewpoint',
          description: 'Panoramic city vista followed by evening drinks.',
          startTime: '18:00',
          endTime: '19:30',
          location: `${destination} Panorama Deck`,
          category: 'Entertainment',
          cost: 15,
          priority: 'Medium',
        },
      ],
    })),
  };

  res.json({ success: true, data: generatedPlan });
});

// -------------------------------------------------------------
// TRIP MEMORIES & REFLECTIONS API (gemini-3.8-flash)
// -------------------------------------------------------------

let TRIP_MEMORIES_STORE: Record<string, any> = {};

app.get('/api/memories/trip/:tripId', (req: Request, res: Response) => {
  const memory = TRIP_MEMORIES_STORE[req.params.tripId] || null;
  res.json({ success: true, data: memory });
});

app.post('/api/memories/trip/:tripId', (req: Request, res: Response) => {
  const memoryData = req.body;
  TRIP_MEMORIES_STORE[req.params.tripId] = memoryData;
  res.json({ success: true, message: 'Trip memories saved successfully', data: memoryData });
});

app.post('/api/ai/memories', async (req: Request, res: Response) => {
  const { tripId, tone = 'poetic', userNotes, customHighlights } = req.body;
  const currentTrip = TRIPS.find((t) => t.id === tripId) || TRIPS[0];
  const tripItinerary = ITINERARY_DAYS.filter((d) => d.tripId === currentTrip.id);
  const tripExpenses = EXPENSES.filter((e) => e.tripId === currentTrip.id);

  const allActivities = tripItinerary.flatMap((d) => d.activities || []);
  const completedActivities = allActivities.filter((a) => a.isCompleted);
  const foodActivities = allActivities.filter((a) => a.category === 'Food');
  const sightActivities = allActivities.filter((a) => a.category === 'Sightseeing' || a.category === 'Culture');

  // If Gemini API is available, generate custom narrative using gemini-3.8-flash
  if (aiClient) {
    try {
      const prompt = `You are TripNest AI's Storyteller & Travel Chronicler.
Analyze the completed trip itinerary and generate an emotionally evocative reflection, highlight reel slides, and trip superlatives.
Trip Details:
- Name: ${currentTrip.tripName}
- Destination: ${currentTrip.destination}, ${currentTrip.country}
- Dates: ${currentTrip.startDate} to ${currentTrip.endDate}
- Travelers: ${currentTrip.travelers} (${currentTrip.ownerName})
- Tone Requested: ${tone} (Options: poetic, adventurous, social, cultural)
- User's Personal Notes: "${userNotes || 'None provided'}"
- Itinerary Days & Completed Activities:
${JSON.stringify(
  tripItinerary.map((d) => ({
    day: d.dayNumber,
    title: d.title,
    summary: d.summary,
    activities: d.activities.map((a) => `${a.name} (${a.category}, ${a.location || currentTrip.destination})`),
  })),
  null,
  2
)}
- Dining & Gastronomy:
${JSON.stringify(tripExpenses.filter((e) => e.category === 'Food').map((e) => e.title), null, 2)}

Return a strict, valid JSON object with the following structure:
{
  "title": "A captivating, beautiful title for this trip memory",
  "tagline": "A poetic, inspiring one-sentence subtitle or motto",
  "summaryNarrative": "A vivid 3-paragraph story written in the specified tone, bringing the sights, smells, sounds, laughter, and cobblestones to life.",
  "keyHighlights": [
    {
      "id": "hl-1",
      "dayNumber": 1,
      "title": "Short title",
      "description": "Vivid detail on why this was a highlight",
      "category": "Sightseeing",
      "badge": "Golden Hour",
      "location": "Location name"
    }
  ],
  "bestMealsAndFlavors": [
    "String describing a specific culinary memory from the itinerary"
  ],
  "unforgettableMoments": [
    "String describing a memorable moment"
  ],
  "superlatives": [
    {
      "id": "sup-1",
      "title": "Traveler Award Title",
      "awardEmoji": "👟",
      "description": "Humorous or appreciative superlative award"
    }
  ],
  "slides": [
    {
      "id": "slide-1",
      "type": "intro",
      "title": "Title",
      "subtitle": "Subtitle",
      "content": "Evocative opening text",
      "stats": "Milestone stat"
    },
    {
      "id": "slide-2",
      "type": "highlight",
      "title": "Highlight Title",
      "subtitle": "Chapter 1",
      "content": "Story of this highlight",
      "badge": "Memorable"
    },
    {
      "id": "slide-3",
      "type": "culinary",
      "title": "Flavors & Tables",
      "subtitle": "Culinary Memories",
      "content": "Story of food and conversations",
      "badge": "Gastronomy"
    },
    {
      "id": "slide-4",
      "type": "superlative",
      "title": "Trip Superlatives",
      "subtitle": "Awards",
      "content": "The awards unlocked by travelers",
      "badge": "Honors"
    },
    {
      "id": "slide-5",
      "type": "epilogue",
      "title": "Farewell",
      "subtitle": "Epilogue",
      "content": "Final heartwarming sign-off quote",
      "stats": "Treasured forever"
    }
  ]
}
Return raw JSON only, no markdown code blocks.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      let jsonText = response.text || '';
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      const parsed = JSON.parse(jsonText);

      const milestones = {
        totalDays: tripItinerary.length || 3,
        totalActivities: allActivities.length || 6,
        completedActivities: completedActivities.length || allActivities.length || 4,
        estimatedSteps: (tripItinerary.length || 3) * 13500,
        estimatedKmWalked: Math.round(((tripItinerary.length || 3) * 9.8) * 10) / 10,
        favoriteDayTitle: tripItinerary[0]?.title || 'Day 1 in ' + currentTrip.destination,
        topCategory: sightActivities.length >= foodActivities.length ? 'Historic Sights & Culture' : 'Culinary & Dining',
      };

      const result = {
        tripId: currentTrip.id,
        tone,
        title: parsed.title || `${currentTrip.destination} Chronicles`,
        tagline: parsed.tagline || `Memories etched in time across ${currentTrip.destination}`,
        summaryNarrative: parsed.summaryNarrative,
        keyHighlights: parsed.keyHighlights || [],
        bestMealsAndFlavors: parsed.bestMealsAndFlavors || [],
        unforgettableMoments: parsed.unforgettableMoments || [],
        superlatives: parsed.superlatives || [],
        slides: parsed.slides || [],
        milestones,
        photos: [
          {
            id: 'ph-1',
            tripId: currentTrip.id,
            url: currentTrip.coverImage || '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
            caption: `Iconic view of ${currentTrip.destination}`,
            location: currentTrip.destination,
            date: currentTrip.startDate,
          },
          {
            id: 'ph-2',
            tripId: currentTrip.id,
            url: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1000&auto=format&fit=crop&q=80',
            caption: 'Sunset across historic cobblestones and terracotta rooftops',
            location: currentTrip.destination,
            date: currentTrip.startDate,
          },
          {
            id: 'ph-3',
            tripId: currentTrip.id,
            url: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?w=1000&auto=format&fit=crop&q=80',
            caption: 'Authentic local cuisine and warm evening chatter',
            location: 'Trastevere',
            date: currentTrip.endDate,
          },
        ],
        userNotes: userNotes || '',
        generatedAt: new Date().toISOString(),
      };

      TRIP_MEMORIES_STORE[currentTrip.id] = result;
      return res.json({ success: true, data: result, engine: 'gemini-3.8-flash' });
    } catch (err) {
      console.warn('Gemini AI Memory generator fallback:', err);
    }
  }

  // Domain-Grounded Intelligent Fallback Synthesis Engine
  const toneAdjectives: Record<string, { mood: string; style: string }> = {
    poetic: { mood: 'lyrical, bittersweet, and evocative', style: 'romantic' },
    adventurous: { mood: 'exhilarating, bold, and high-energy', style: 'thrilling' },
    social: { mood: 'lively, vibrant, and fun-filled', style: 'playful' },
    cultural: { mood: 'contemplative, deeply historical, and enriching', style: 'reverent' },
  };

  const selectedTone = toneAdjectives[tone] || toneAdjectives.poetic;

  const keyMoments = allActivities.slice(0, 4).map((a, idx) => ({
    id: `hl-${idx + 1}`,
    dayNumber: a.dayId?.includes('1') ? 1 : a.dayId?.includes('2') ? 2 : 3,
    title: a.name,
    description: a.description || `Unforgettable experience at ${a.location || currentTrip.destination}.`,
    category: a.category || 'Sightseeing',
    badge: idx === 0 ? 'Iconic Landmark' : idx === 1 ? 'Golden Hour' : idx === 2 ? 'Chef Selection' : 'Scenic Walk',
    location: a.location || currentTrip.destination,
  }));

  const fallbackSuperlatives = [
    {
      id: 'sup-1',
      title: 'Pavement Master & Step Legend',
      awardEmoji: '👟',
      description: `Clocked over ${((tripItinerary.length || 3) * 12800).toLocaleString()} steps navigating ancient basalt stone alleys.`,
    },
    {
      id: 'sup-2',
      title: 'Culinary Purist & Flavor Seeker',
      awardEmoji: '🍝',
      description: 'Found authentic, mouth-watering local delicacies tucked behind bustling main avenues.',
    },
    {
      id: 'sup-3',
      title: 'Golden Hour Storyteller',
      awardEmoji: '🌅',
      description: 'Never missed a scenic sunset or sunrise photo opportunity across the cityscape.',
    },
    {
      id: 'sup-4',
      title: 'Squad Compass & Navigator',
      awardEmoji: '🧭',
      description: 'Masterfully kept the group on schedule while finding unexpected hidden courtyards.',
    },
  ];

  const narrativeParagraphs = [
    `From the very first morning in ${currentTrip.destination}, the city revealed its captivating spirit. The crisp air, the gentle hum of morning scooters and church bells, and the timeless golden glow warming the centuries-old facades turned each quiet walk into a personal chapter. Exploring ${tripItinerary[0]?.title || currentTrip.destination} alongside ${currentTrip.travelers} travel companions created an effortless camaraderie that made every turn of the corner an invitation to wonder.`,
    `The heart of the journey beat brightest through the itinerary highlights: standing in awe beneath the towering arches of the Colosseum and Forum, tracing the delicate marble whispers in the Vatican, and lingering past twilight along the lantern-lit cobblestones of Trastevere. Meals were never merely dining—they were celebratory rituals, where handmade pasta, fragrant local wine, and warm bread sparked laughter that spilled well past midnight.`,
    `As the final suitcase was zipped and the boarding passes printed, what remained was not merely a collection of souvenirs, but a tapestry of indelible memories: the cool spray of Trevi’s fountains, the taste of velvety pistachio gelato, and the quiet promise that some part of ${currentTrip.destination} will always remain in our hearts.`,
  ];

  const slides = [
    {
      id: 'slide-1',
      type: 'intro',
      title: `${currentTrip.destination} Odyssey`,
      subtitle: `${currentTrip.startDate} — ${currentTrip.endDate}`,
      content: `A memorable ${tripItinerary.length || 5}-day sojourn steeped in history, flavor, and discovery with ${currentTrip.travelers} explorers.`,
      imageUrl: currentTrip.coverImage || '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
      stats: `${tripItinerary.length || 5} Days • ${allActivities.length || 8} Activities`,
    },
    {
      id: 'slide-2',
      type: 'highlight',
      title: keyMoments[0]?.title || 'Ancient Marvels',
      subtitle: 'Day 1 • Imperial Footsteps',
      content: keyMoments[0]?.description || 'Stepping into the gladiators arena as afternoon light swept across the stone tiers.',
      badge: 'Unforgettable Sight',
      imageUrl: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1000&auto=format&fit=crop&q=80',
    },
    {
      id: 'slide-3',
      type: 'culinary',
      title: 'Trattorias & Evening Wine',
      subtitle: 'Feasts & Flavors',
      content: 'Authentic cacio e pepe, crisp Roman artichokes, and shared laughter over carafes of local Frascati.',
      badge: 'Culinary Highlight',
      imageUrl: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?w=1000&auto=format&fit=crop&q=80',
    },
    {
      id: 'slide-4',
      type: 'superlative',
      title: 'Traveler Honors & Superlatives',
      subtitle: 'Squad Superlatives',
      content: `${fallbackSuperlatives[0].awardEmoji} ${fallbackSuperlatives[0].title}: ${fallbackSuperlatives[0].description}`,
      badge: 'Superlatives',
      imageUrl: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=1000&auto=format&fit=crop&q=80',
    },
    {
      id: 'slide-5',
      type: 'epilogue',
      title: 'Until We Wander Again',
      subtitle: 'Journey Reflection',
      content: '“We travel not to escape life, but for life not to escape us.” Rome will always be here waiting.',
      stats: 'Memories safely archived',
      imageUrl: currentTrip.coverImage || '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    },
  ];

  const milestones = {
    totalDays: tripItinerary.length || 3,
    totalActivities: allActivities.length || 8,
    completedActivities: completedActivities.length || 6,
    estimatedSteps: (tripItinerary.length || 3) * 14200,
    estimatedKmWalked: Math.round(((tripItinerary.length || 3) * 10.4) * 10) / 10,
    favoriteDayTitle: tripItinerary[0]?.title || 'Arrival & Imperial Forum',
    topCategory: 'Sightseeing & Culture',
  };

  const fallbackMemory = {
    tripId: currentTrip.id,
    title: `${currentTrip.destination} Unveiled: A Chronicle of Wonder`,
    tagline: `Golden sunlight, sacred corridors, and midnight laughter in ${currentTrip.destination}`,
    summaryNarrative: narrativeParagraphs.join('\n\n'),
    tone,
    keyHighlights: keyMoments,
    bestMealsAndFlavors: [
      'Authentic cacio e pepe and fried artichokes alla romana at Trattoria Monti',
      'Artisanal pistachio & stracciatella gelato savored by the Spanish Steps',
      'Trastevere sunset natural red wine paired with warm focaccia and pecorino',
    ],
    unforgettableMoments: [
      'Tossing a brass coin over the left shoulder into the glowing Trevi Fountain at dawn',
      'Marveling up at the open oculus of the Pantheon while raindrops drifted inside',
      'Cycling beneath the shaded umbrella pines of Villa Borghese gardens',
    ],
    superlatives: fallbackSuperlatives,
    slides,
    milestones,
    photos: [
      {
        id: 'ph-1',
        tripId: currentTrip.id,
        url: currentTrip.coverImage || '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
        caption: `Gladiator arches at the Colosseum in ${currentTrip.destination}`,
        location: currentTrip.destination,
        date: currentTrip.startDate,
      },
      {
        id: 'ph-2',
        tripId: currentTrip.id,
        url: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1000&auto=format&fit=crop&q=80',
        caption: 'Golden hour descending over ancient cobblestone avenues',
        location: currentTrip.destination,
        date: currentTrip.startDate,
      },
      {
        id: 'ph-3',
        tripId: currentTrip.id,
        url: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?w=1000&auto=format&fit=crop&q=80',
        caption: 'Lantern-lit dinner tables in Trastevere',
        location: 'Trastevere',
        date: currentTrip.endDate,
      },
      {
        id: 'ph-4',
        tripId: currentTrip.id,
        url: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=1000&auto=format&fit=crop&q=80',
        caption: 'Trevi Fountain illuminated beneath the night sky',
        location: 'Piazza di Trevi',
        date: currentTrip.startDate,
      },
    ],
    userNotes: userNotes || '',
    generatedAt: new Date().toISOString(),
  };

  TRIP_MEMORIES_STORE[currentTrip.id] = fallbackMemory;
  res.json({ success: true, data: fallbackMemory, engine: 'domain-synthesis-engine' });
});

// -------------------------------------------------------------
// VITE INTEGRATION & SERVER STARTUP
// -------------------------------------------------------------

async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TripNest server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
