export type Role = 'TRAVELER' | 'GROUP_ADMIN' | 'ADMIN';

export interface User {
  id: string;
  fullName: string;
  email: string;
  avatarUrl?: string;
  country: string;
  preferredCurrency: string;
  travelPreferences: string[];
  role: Role;
  createdAt: string;
}

export type TripStatus = 'PLANNING' | 'UPCOMING' | 'ONGOING' | 'COMPLETED' | 'CANCELLED';
export type TripVisibility = 'PRIVATE' | 'GROUP' | 'PUBLIC';
export type TravelStyle = 'Budget' | 'Standard' | 'Luxury' | 'Adventure' | 'Family' | 'Couple' | 'Solo' | 'Business';

export interface Trip {
  id: string;
  tripName: string;
  description: string;
  destination: string;
  country: string;
  startDate: string;
  endDate: string;
  travelers: number;
  budget: number;
  spent: number;
  currency: string;
  status: TripStatus;
  visibility: TripVisibility;
  coverImage: string;
  ownerId: string;
  ownerName: string;
  travelStyle: TravelStyle;
  groupId?: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  createdAt: string;
  updatedAt: string;
}

export type ActivityCategory = 
  | 'Sightseeing'
  | 'Food'
  | 'Hotel'
  | 'Transport'
  | 'Adventure'
  | 'Shopping'
  | 'Entertainment'
  | 'Culture'
  | 'Nature'
  | 'Other';

export interface Activity {
  id: string;
  dayId: string;
  tripId: string;
  name: string;
  description: string;
  startTime: string;
  endTime: string;
  location: string;
  category: ActivityCategory;
  cost: number;
  currency: string;
  notes?: string;
  imageUrl?: string;
  priority: 'Low' | 'Medium' | 'High';
  isCompleted: boolean;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface ItineraryDay {
  id: string;
  tripId: string;
  dayNumber: number;
  date: string;
  title: string;
  summary: string;
  activities: Activity[];
}

export type ExpenseCategory =
  | 'Flights'
  | 'Accommodation'
  | 'Food'
  | 'Transportation'
  | 'Activities'
  | 'Shopping'
  | 'Entertainment'
  | 'Insurance'
  | 'Other';

export interface ExpenseSplit {
  userId: string;
  userName: string;
  amount: number;
  settled: boolean;
}

export interface Expense {
  id: string;
  tripId: string;
  title: string;
  amount: number;
  currency: string;
  category: ExpenseCategory;
  date: string;
  paidById: string;
  paidByName: string;
  paymentMethod: 'Credit Card' | 'Cash' | 'Bank Transfer' | 'UPI' | 'Other';
  notes?: string;
  receiptUrl?: string;
  splits: ExpenseSplit[];
}

export interface Settlement {
  fromUser: string;
  toUser: string;
  amount: number;
  currency: string;
}

export interface GroupMember {
  userId: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: 'Owner' | 'Admin' | 'Member';
  joinedAt: string;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
  tripId?: string;
  members: GroupMember[];
  createdAt: string;
}

export type DocumentCategory =
  | 'Passport'
  | 'Visa'
  | 'Flight Tickets'
  | 'Hotel Bookings'
  | 'Travel Insurance'
  | 'Identity Documents'
  | 'Other';

export interface TravelDocument {
  id: string;
  tripId: string;
  name: string;
  category: DocumentCategory;
  fileSize: string;
  fileType: string;
  uploadDate: string;
  expiryDate?: string;
  fileUrl: string;
  notes?: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'TRIP' | 'BUDGET' | 'GROUP' | 'WEATHER' | 'AI' | 'DOCUMENT';
  isRead: boolean;
  timestamp: string;
  actionUrl?: string;
}

export interface Destination {
  id: string;
  name: string;
  country: string;
  region: string;
  category: 'Popular' | 'Trending' | 'Adventure' | 'Beaches' | 'Mountains' | 'Historical' | 'Luxury' | 'Budget Friendly';
  rating: number;
  shortDescription: string;
  longDescription: string;
  imageUrl: string;
  averageCostPerDay: number;
  bestTimeToVisit: string;
  currentWeather: {
    temp: number;
    condition: string;
    icon: string;
  };
  topAttractions: {
    name: string;
    description: string;
    imageUrl?: string;
    estimatedCost: number;
  }[];
  travelTips: string[];
  safetyInfo: string;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface CurrencyRate {
  code: string;
  symbol: string;
  name: string;
  rateAgainstUSD: number;
}

export interface WeatherForecastDay {
  day: string;
  date: string;
  temp: number;
  tempMin: number;
  tempMax: number;
  condition: string;
  humidity: number;
  icon: string;
}

export interface DestinationWeather {
  city: string;
  currentTemp: number;
  condition: string;
  humidity: number;
  windSpeed: string;
  icon: string;
  forecast: WeatherForecastDay[];
}

export interface AIMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  actions?: AIProposalAction[];
  structuredData?: any;
}

export interface AIProposalAction {
  id: string;
  type: 'ADD_ACTIVITY' | 'REARRANGE_ITINERARY' | 'OPTIMIZE_BUDGET' | 'GENERATE_PACKING_LIST' | 'CHANGE_TRIP_DETAILS';
  label: string;
  description: string;
  payload: any;
  status: 'PENDING' | 'APPLIED' | 'DISMISSED';
}
