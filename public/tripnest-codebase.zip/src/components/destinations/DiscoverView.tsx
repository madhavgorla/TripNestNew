import React, { useState, useEffect } from 'react';
import {
  Search,
  Heart,
  Star,
  Compass,
  CloudSun,
  Sun,
  CloudRain,
  MapPin,
  Calendar,
  DollarSign,
  ArrowRight,
  Info,
  Shield,
  Plus,
} from 'lucide-react';
import { Destination } from '../../types';
import { api } from '../../services/api';
import { useCurrency } from '../../context/CurrencyContext';

interface DiscoverViewProps {
  onPlanTripForDestination: (dest: Destination) => void;
}

export const DiscoverView: React.FC<DiscoverViewProps> = ({ onPlanTripForDestination }) => {
  const { formatPrice, currentCurrency } = useCurrency();

  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [favoriteIds, setFavoriteIds] = useState<string[]>(['dest-rome', 'dest-bali']);
  const [selectedDest, setSelectedDest] = useState<Destination | null>(null);

  const categories = ['All', 'Historical', 'Beaches', 'Popular', 'Trending', 'Luxury'];

  useEffect(() => {
    loadDestinations();
  }, [selectedCategory, searchQuery]);

  const loadDestinations = async () => {
    try {
      const res = await api.getDestinations(selectedCategory, searchQuery);
      if (res.success) {
        setDestinations(res.data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const toggleFavorite = async (destId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await api.toggleFavorite(destId);
      if (res.success) {
        if (res.isFavorited) {
          setFavoriteIds((prev) => [...prev, destId]);
        } else {
          setFavoriteIds((prev) => prev.filter((id) => id !== destId));
        }
      }
    } catch (err) {}
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white font-display">
            Discover Global Destinations
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Curated guides, average daily budgets, top attractions, and local weather forecasts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search destination..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="rounded-xl border border-slate-200 bg-white pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:border-slate-800 dark:bg-slate-900 dark:text-white focus:outline-hidden w-48 sm:w-64"
            />
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`rounded-xl px-4 py-2 text-xs font-semibold whitespace-nowrap transition-colors ${
              selectedCategory === cat
                ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Destinations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {destinations.map((dest) => {
          const isFav = favoriteIds.includes(dest.id);
          return (
            <div
              key={dest.id}
              onClick={() => setSelectedDest(dest)}
              className="group flex flex-col justify-between rounded-3xl border border-slate-200 bg-white overflow-hidden shadow-xs hover:shadow-md hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700 transition-all cursor-pointer"
            >
              <div className="relative h-48 w-full overflow-hidden">
                <img
                  src={dest.imageUrl}
                  alt={dest.name}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent" />

                {/* Rating Badge */}
                <div className="absolute top-3 left-3 flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-bold text-slate-900 shadow-xs backdrop-blur-md">
                  <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                  <span>{dest.rating}</span>
                </div>

                {/* Favorite Heart Button */}
                <button
                  onClick={(e) => toggleFavorite(dest.id, e)}
                  className="absolute top-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-slate-700 shadow-xs hover:scale-110 backdrop-blur-md transition-all"
                >
                  <Heart
                    className={`w-4 h-4 ${isFav ? 'text-rose-500 fill-rose-500' : 'text-slate-600'}`}
                  />
                </button>

                {/* Location Title Over Image */}
                <div className="absolute bottom-3 left-3 text-white">
                  <h3 className="text-base font-bold drop-shadow-xs">{dest.name}</h3>
                  <p className="text-xs text-white/90 drop-shadow-xs flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-indigo-300" />
                    <span>{dest.country}</span>
                  </p>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                    {dest.shortDescription}
                  </p>

                  <div className="mt-3 flex items-center justify-between text-xs border-t border-slate-100 pt-3 dark:border-slate-800">
                    <div className="flex items-center gap-1.5 text-slate-500">
                      <Sun className="w-4 h-4 text-amber-500" />
                      <span>{dest.currentWeather?.temp}°C • {dest.currentWeather?.condition}</span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Avg. Daily Cost</span>
                      <span className="font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                        {formatPrice(dest.averageCostPerDay, 'USD')} / day
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-slate-800">
                  <span className="text-[11px] text-slate-400">
                    Best: {dest.bestTimeToVisit}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlanTripForDestination(dest);
                    }}
                    className="flex items-center gap-1 rounded-xl bg-slate-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Plan Trip</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Destination Detailed Modal */}
      {selectedDest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-900 animate-in fade-in zoom-in-95 duration-150">
            <div className="relative h-64 w-full">
              <img
                src={selectedDest.imageUrl}
                alt={selectedDest.name}
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
              <button
                onClick={() => setSelectedDest(null)}
                className="absolute top-4 right-4 flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/80"
              >
                ✕
              </button>
              <div className="absolute bottom-4 left-6 text-white">
                <span className="rounded-full bg-indigo-600/90 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                  {selectedDest.category}
                </span>
                <h2 className="text-2xl font-bold mt-1">{selectedDest.name}, {selectedDest.country}</h2>
                <p className="text-xs text-slate-300">⭐ {selectedDest.rating} Rating • Best Season: {selectedDest.bestTimeToVisit}</p>
              </div>
            </div>

            <div className="p-6 space-y-5">
              <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                {selectedDest.longDescription}
              </p>

              {/* Weather & Average Cost Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 rounded-2xl bg-slate-50 p-4 dark:bg-slate-800/50">
                <div>
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Current Climate
                  </span>
                  <p className="text-sm font-bold text-slate-900 dark:text-white mt-0.5">
                    {selectedDest.currentWeather?.temp}°C ({selectedDest.currentWeather?.condition})
                  </p>
                </div>
                <div>
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Avg. Daily Cost
                  </span>
                  <p className="text-sm font-bold font-mono text-slate-900 dark:text-white mt-0.5">
                    {formatPrice(selectedDest.averageCostPerDay, 'USD')}
                  </p>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Safety Status
                  </span>
                  <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5">
                    {selectedDest.safetyInfo}
                  </p>
                </div>
              </div>

              {/* Top Attractions */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-2.5">
                  Must-Visit Attractions
                </h4>
                <div className="space-y-2">
                  {selectedDest.topAttractions.map((att, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-3 rounded-xl border border-slate-100 bg-slate-50/50 dark:border-slate-800 dark:bg-slate-800/40 text-xs"
                    >
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{att.name}</p>
                        <p className="text-[11px] text-slate-500">{att.description}</p>
                      </div>
                      <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
                        {att.estimatedCost > 0 ? formatPrice(att.estimatedCost, 'USD') : 'Free'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Travel Tips */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-2">
                  Insider Travel Tips
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400 list-disc list-inside">
                  {selectedDest.travelTips.map((tip, idx) => (
                    <li key={idx}>{tip}</li>
                  ))}
                </ul>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setSelectedDest(null)}
                  className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const dest = selectedDest;
                    setSelectedDest(null);
                    onPlanTripForDestination(dest);
                  }}
                  className="flex items-center gap-2 rounded-xl bg-indigo-600 px-5 py-2 text-xs font-semibold text-white hover:bg-indigo-700 transition-colors shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Build Itinerary for {selectedDest.name}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
