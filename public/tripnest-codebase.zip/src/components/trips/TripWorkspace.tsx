import React, { useState } from 'react';
import {
  Calendar,
  MapPin,
  Users,
  Wallet,
  Sparkles,
  Trash2,
  Share2,
  Map as MapIcon,
  ListOrdered,
  FileCheck,
  UserCheck,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { useTrip } from '../../context/TripContext';
import { useCurrency } from '../../context/CurrencyContext';
import { ItineraryTimeline } from '../itinerary/ItineraryTimeline';
import { TripMap } from '../maps/TripMap';
import { BudgetManager } from '../budget/BudgetManager';
import { GroupManager } from '../groups/GroupManager';
import { DocumentVault } from '../documents/DocumentVault';

interface TripWorkspaceProps {
  onOpenAiCopilot: () => void;
}

export const TripWorkspace: React.FC<TripWorkspaceProps> = ({ onOpenAiCopilot }) => {
  const { activeTrip, itineraryDays, deleteTrip, trips, setActiveTripById } = useTrip();
  const { formatPrice } = useCurrency();

  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<'itinerary' | 'budget' | 'group' | 'documents'>('itinerary');
  const [selectedActivityId, setSelectedActivityId] = useState<string | undefined>(undefined);
  const [layoutMode, setLayoutMode] = useState<'split' | 'timeline' | 'map'>('split');

  if (!activeTrip) {
    return (
      <div className="rounded-3xl border border-dashed border-slate-300 p-12 text-center dark:border-slate-800">
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">No Active Trip Selected</p>
        <p className="text-xs text-slate-400 mt-1">Select an existing journey or build a new one with AI.</p>
      </div>
    );
  }

  // Flatten all activities for the map
  const allActivities = itineraryDays.flatMap((day) => day.activities);

  const totalSpent = activeTrip.spent || 0;
  const budgetRatio = Math.min(100, Math.round((totalSpent / (activeTrip.budget || 1)) * 100));

  return (
    <div className="space-y-6">
      {/* Hero Workspace Header */}
      <div className="relative rounded-3xl overflow-hidden border border-slate-200 bg-white shadow-xs dark:border-slate-800 dark:bg-slate-900">
        <div className="relative h-56 sm:h-64 w-full">
          <img
            src={activeTrip.coverImage}
            alt={activeTrip.tripName}
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />

          {/* Top Bar Badges */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-slate-900 shadow-xs backdrop-blur-md">
                {activeTrip.status}
              </span>
              <span className="rounded-full bg-indigo-600/90 px-3 py-1 text-xs font-semibold text-white shadow-xs backdrop-blur-md">
                {activeTrip.travelStyle} Style
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onOpenAiCopilot}
                className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 px-3 py-1 text-xs font-semibold text-white shadow-xs hover:from-indigo-700 hover:to-purple-700 backdrop-blur-md transition-all cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                <span>TripNest AI</span>
              </button>

              <button
                onClick={() => {
                  if (confirm(`Are you sure you want to delete "${activeTrip.tripName}"?`)) {
                    deleteTrip(activeTrip.id);
                  }
                }}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-slate-200 hover:bg-rose-600 hover:text-white backdrop-blur-md transition-all"
                title="Delete Trip"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Bottom Title & Stats */}
          <div className="absolute bottom-4 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4 text-white">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight drop-shadow-xs font-display">
                {activeTrip.tripName}
              </h1>
              <div className="mt-1 flex flex-wrap items-center gap-4 text-xs text-slate-200">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                  {activeTrip.destination}, {activeTrip.country}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-300" />
                  {activeTrip.startDate} to {activeTrip.endDate}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-300" />
                  {activeTrip.travelers} Traveler(s)
                </span>
              </div>
            </div>

            {/* Budget Progress Bar Chip */}
            <div className="w-full sm:w-64 rounded-2xl bg-white/10 p-3 backdrop-blur-md border border-white/20">
              <div className="flex justify-between text-xs font-semibold">
                <span>Budget Progress</span>
                <span className="font-mono tabular-nums">
                  {formatPrice(totalSpent, activeTrip.currency)} / {formatPrice(activeTrip.budget, activeTrip.currency)}
                </span>
              </div>
              <div className="mt-2 w-full bg-white/20 rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-1.5 rounded-full transition-all duration-500 ${
                    budgetRatio > 90 ? 'bg-rose-500' : 'bg-emerald-400'
                  }`}
                  style={{ width: `${budgetRatio}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Tab Controls Bar */}
        <div className="flex items-center justify-between border-t border-slate-100 px-6 py-2 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveWorkspaceTab('itinerary')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition-colors ${
                activeWorkspaceTab === 'itinerary'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Itinerary & Map
            </button>
            <button
              onClick={() => setActiveWorkspaceTab('budget')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition-colors ${
                activeWorkspaceTab === 'budget'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Budget & Expenses
            </button>
            <button
              onClick={() => setActiveWorkspaceTab('group')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition-colors ${
                activeWorkspaceTab === 'group'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Travel Group
            </button>
            <button
              onClick={() => setActiveWorkspaceTab('documents')}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition-colors ${
                activeWorkspaceTab === 'documents'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
              }`}
            >
              Document Vault
            </button>
          </div>

          {activeWorkspaceTab === 'itinerary' && (
            <div className="hidden sm:flex items-center gap-1 bg-white dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700 text-xs">
              <button
                onClick={() => setLayoutMode('split')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  layoutMode === 'split' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500'
                }`}
              >
                Split View
              </button>
              <button
                onClick={() => setLayoutMode('timeline')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  layoutMode === 'timeline' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500'
                }`}
              >
                Timeline Only
              </button>
              <button
                onClick={() => setLayoutMode('map')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  layoutMode === 'map' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500'
                }`}
              >
                Map Only
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Tab Content */}
      {activeWorkspaceTab === 'itinerary' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Itinerary Timeline Column */}
          {(layoutMode === 'split' || layoutMode === 'timeline') && (
            <div className={layoutMode === 'split' ? 'lg:col-span-7' : 'lg:col-span-12'}>
              <ItineraryTimeline
                days={itineraryDays}
                selectedActivityId={selectedActivityId}
                onSelectActivity={(actId) => setSelectedActivityId(actId)}
                tripCurrency={activeTrip.currency}
              />
            </div>
          )}

          {/* Interactive Leaflet Map Column */}
          {(layoutMode === 'split' || layoutMode === 'map') && (
            <div
              className={`sticky top-20 ${
                layoutMode === 'split' ? 'lg:col-span-5 h-[580px]' : 'lg:col-span-12 h-[680px]'
              }`}
            >
              <TripMap
                center={activeTrip.coordinates || { lat: 41.9028, lng: 12.4964 }}
                activities={allActivities}
                selectedActivityId={selectedActivityId}
                onSelectActivity={(actId) => setSelectedActivityId(actId)}
                destinationName={activeTrip.destination}
              />
            </div>
          )}
        </div>
      )}

      {activeWorkspaceTab === 'budget' && (
        <BudgetManager
          tripId={activeTrip.id}
          totalBudget={activeTrip.budget}
          tripCurrency={activeTrip.currency}
        />
      )}

      {activeWorkspaceTab === 'group' && <GroupManager />}

      {activeWorkspaceTab === 'documents' && <DocumentVault />}
    </div>
  );
};
