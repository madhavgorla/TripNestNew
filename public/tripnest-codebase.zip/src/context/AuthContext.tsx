import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password?: string) => Promise<boolean>;
  register: (data: any) => Promise<boolean>;
  loginWithGoogle: () => Promise<boolean>;
  logout: () => void;
  switchRole: (role: Role) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>({
    id: 'usr-1',
    fullName: 'Lara Croft',
    email: 'lara@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    country: 'United Kingdom',
    preferredCurrency: 'USD',
    travelPreferences: ['Historical', 'Adventure', 'Photography'],
    role: 'TRAVELER',
    createdAt: '2026-01-15T08:00:00Z',
  });
  const [token, setToken] = useState<string | null>(localStorage.getItem('tripnest_token') || 'jwt_token_usr-1');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    // If token exists, load me
    api.getCurrentUser()
      .then((res) => {
        if (res.success && res.data) {
          setUser(res.data);
        }
      })
      .catch(() => {});
  }, []);

  const login = async (email: string, password?: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await api.login(email, password);
      if (res.success && res.data) {
        setUser(res.data.user);
        setToken(res.data.accessToken);
        localStorage.setItem('tripnest_token', res.data.accessToken);
        return true;
      }
      return false;
    } catch (err) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: any): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await api.register(data);
      if (res.success && res.data) {
        setUser(res.data.user);
        setToken(res.data.accessToken);
        localStorage.setItem('tripnest_token', res.data.accessToken);
        return true;
      }
      return false;
    } catch (err) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async (): Promise<boolean> => {
    setIsLoading(true);
    try {
      const res = await api.loginWithGoogle();
      if (res.success && res.data) {
        setUser(res.data.user);
        setToken(res.data.accessToken);
        localStorage.setItem('tripnest_token', res.data.accessToken);
        return true;
      }
      return false;
    } catch (err) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('tripnest_token');
  };

  const switchRole = (newRole: Role) => {
    if (!user) return;
    let updatedUser: User = { ...user, role: newRole };
    if (newRole === 'ADMIN') {
      updatedUser = {
        ...updatedUser,
        id: 'usr-admin',
        fullName: 'TripNest Admin',
        email: 'admin@tripnest.com',
      };
    } else if (newRole === 'GROUP_ADMIN') {
      updatedUser = {
        ...updatedUser,
        id: 'usr-2',
        fullName: 'Madhav Sharma',
        email: 'madhav@tripnest.com',
      };
    } else {
      updatedUser = {
        ...updatedUser,
        id: 'usr-1',
        fullName: 'Lara Croft',
        email: 'lara@tripnest.com',
      };
    }
    setUser(updatedUser);
    localStorage.setItem('tripnest_token', `jwt_token_${updatedUser.id}`);
  };

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, register, loginWithGoogle, logout, switchRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
