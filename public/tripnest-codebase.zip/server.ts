import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI client if GEMINI_API_KEY is available
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  } catch (e) {
    console.warn('Failed to initialize GoogleGenAI client:', e);
  }
}

// -------------------------------------------------------------
// IN-MEMORY / PERSISTENT DATA LAYER (PostgreSQL Seed Mirror)
// -------------------------------------------------------------

const USERS = [
  {
    id: 'usr-1',
    fullName: 'Lara Croft',
    email: 'lara@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    country: 'United Kingdom',
    preferredCurrency: 'USD',
    travelPreferences: ['Historical', 'Adventure', 'Photography'],
    role: 'TRAVELER',
    createdAt: '2026-01-15T08:00:00Z',
  },
  {
    id: 'usr-2',
    fullName: 'Madhav Sharma',
    email: 'madhav@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    country: 'India',
    preferredCurrency: 'INR',
    travelPreferences: ['Cultural', 'Beaches', 'Food'],
    role: 'GROUP_ADMIN',
    createdAt: '2026-01-20T10:00:00Z',
  },
  {
    id: 'usr-admin',
    fullName: 'TripNest Admin',
    email: 'admin@tripnest.com',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    country: 'United States',
    preferredCurrency: 'USD',
    travelPreferences: ['System Management', 'Analytics'],
    role: 'ADMIN',
    createdAt: '2026-01-01T00:00:00Z',
  },
];

let TRIPS = [
  {
    id: 'trip-rome-2026',
    tripName: 'Rome Cultural Escape',
    description: 'An immersive 5-day journey through the heart of the Roman Empire, classical renaissance art, and authentic Italian gastronomy.',
    destination: 'Rome',
    country: 'Italy',
    startDate: '2026-10-10',
    endDate: '2026-10-15',
    travelers: 2,
    budget: 3200,
    spent: 2450,
    currency: 'USD',
    status: 'UPCOMING',
    visibility: 'GROUP',
    coverImage: '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    ownerId: 'usr-1',
    ownerName: 'Lara Croft',
    travelStyle: 'Standard',
    groupId: 'grp-rome',
    coordinates: { lat: 41.9028, lng: 12.4964 },
    createdAt: '2026-02-01T10:00:00Z',
    updatedAt: '2026-02-10T14:30:00Z',
  },
  {
    id: 'trip-goa-2026',
    tripName: 'Goa Coastal Odyssey',
    description: 'Sun, sand, Portuguese heritage architecture, and coastal seafood explorations with friends.',
    destination: 'Goa',
    country: 'India',
    startDate: '2026-11-05',
    endDate: '2026-11-10',
    travelers: 4,
    budget: 65000,
    spent: 38200,
    currency: 'INR',
    status: 'PLANNING',
    visibility: 'GROUP',
    coverImage: '/src/assets/images/dest_goa_beach_1790172797821.jpg',
    ownerId: 'usr-2',
    ownerName: 'Madhav Sharma',
    travelStyle: 'Adventure',
    groupId: 'grp-goa',
    coordinates: { lat: 15.2993, lng: 74.124 },
    createdAt: '2026-02-12T09:00:00Z',
    updatedAt: '2026-02-15T11:20:00Z',
  },
  {
    id: 'trip-bali-2026',
    tripName: 'Bali Spiritual & Nature Retreat',
    description: 'Exploring ancient water temples, Ubud emerald rice terraces, and Mount Batur sunrise hike.',
    destination: 'Bali',
    country: 'Indonesia',
    startDate: '2026-12-01',
    endDate: '2026-12-08',
    travelers: 2,
    budget: 2800,
    spent: 950,
    currency: 'USD',
    status: 'PLANNING',
    visibility: 'PRIVATE',
    coverImage: '/src/assets/images/dest_bali_temple_1790172783309.jpg',
    ownerId: 'usr-1',
    ownerName: 'Lara Croft',
    travelStyle: 'Luxury',
    coordinates: { lat: -8.4095, lng: 115.1889 },
    createdAt: '2026-02-18T16:00:00Z',
    updatedAt: '2026-02-18T16:00:00Z',
  },
];

let ITINERARY_DAYS = [
  {
    id: 'day-rome-1',
    tripId: 'trip-rome-2026',
    dayNumber: 1,
    date: '2026-10-10',
    title: 'Arrival & Ancient Roman Forum',
    summary: 'Touchdown in Leonardo da Vinci airport, hotel check-in in Monti, followed by an afternoon at the Colosseum and Roman Forum.',
    activities: [
      {
        id: 'act-1',
        dayId: 'day-rome-1',
        tripId: 'trip-rome-2026',
        name: 'Check into Hotel Artemide',
        description: 'Boutique hotel in Via Nazionale. Drop off baggage and refresh.',
        startTime: '10:00',
        endTime: '11:00',
        location: 'Via Nazionale 22, Rome',
        category: 'Hotel',
        cost: 320,
        currency: 'USD',
        notes: 'Reservation code: IT-ROM-9821. Late checkout requested.',
        priority: 'High',
        isCompleted: true,
        coordinates: { lat: 41.9015, lng: 12.4925 },
      },
      {
        id: 'act-2',
        dayId: 'day-rome-1',
        tripId: 'trip-rome-2026',
        name: 'Colosseum & Roman Forum Tour',
        description: 'Skip-the-line VIP guided tour of the gladiators arena and Roman Forum.',
        startTime: '13:00',
        endTime: '16:00',
        location: 'Piazza del Colosseo 1, Rome',
        category: 'Sightseeing',
        cost: 110,
        currency: 'USD',
        notes: 'Bring ID and e-tickets. Sunscreen recommended.',
        priority: 'High',
        isCompleted: true,
        coordinates: { lat: 41.8902, lng: 12.4922 },
      },
      {
        id: 'act-3',
        dayId: 'day-rome-1',
        tripId: 'trip-rome-2026',
        name: 'Dinner at Trattoria Monti',
        description: 'Authentic cacio e pepe, artichokes alla romana, and local Frascati white wine.',
        startTime: '19:30',
        endTime: '21:30',
        location: 'Via di San Vito 13, Rome',
        category: 'Food',
        cost: 95,
        currency: 'USD',
        notes: 'Table booked under Croft for 2 persons.',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.8967, lng: 12.5011 },
      },
    ],
  },
  {
    id: 'day-rome-2',
    tripId: 'trip-rome-2026',
    dayNumber: 2,
    date: '2026-10-11',
    title: 'Vatican City & Trastevere Evenings',
    summary: 'St. Peter Basilica, Sistine Chapel, followed by a scenic walk across Tiber river for gelato and sunset.',
    activities: [
      {
        id: 'act-4',
        dayId: 'day-rome-2',
        tripId: 'trip-rome-2026',
        name: 'Vatican Museums & Sistine Chapel',
        description: 'Explore Renaissance masterpieces by Michelangelo and Raphael.',
        startTime: '08:30',
        endTime: '12:00',
        location: 'Viale Vaticano, 00165 Roma',
        category: 'Culture',
        cost: 85,
        currency: 'USD',
        notes: 'Strict dress code: shoulders and knees covered.',
        priority: 'High',
        isCompleted: false,
        coordinates: { lat: 41.9065, lng: 12.4536 },
      },
      {
        id: 'act-5',
        dayId: 'day-rome-2',
        tripId: 'trip-rome-2026',
        name: 'Piazza Navona & Pantheon',
        description: 'Stroll around Berninis Fountain of the Four Rivers and the ancient Roman Pantheon.',
        startTime: '14:30',
        endTime: '17:00',
        location: 'Piazza della Rotonda, Rome',
        category: 'Sightseeing',
        cost: 15,
        currency: 'USD',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.8986, lng: 12.4769 },
      },
      {
        id: 'act-6',
        dayId: 'day-rome-2',
        tripId: 'trip-rome-2026',
        name: 'Trastevere Sunset & Wine Bar',
        description: 'Charming cobblestone alleyways, street performers, and natural wine tasting.',
        startTime: '18:30',
        endTime: '21:00',
        location: 'Piazza di Santa Maria in Trastevere, Rome',
        category: 'Entertainment',
        cost: 60,
        currency: 'USD',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.8895, lng: 12.4705 },
      },
    ],
  },
  {
    id: 'day-rome-3',
    tripId: 'trip-rome-2026',
    dayNumber: 3,
    date: '2026-10-12',
    title: 'Trevi Fountain & Villa Borghese Gardens',
    summary: 'Coin toss at Trevi, luxury shopping near Spanish Steps, and renting bicycles in Borghese park.',
    activities: [
      {
        id: 'act-7',
        dayId: 'day-rome-3',
        tripId: 'trip-rome-2026',
        name: 'Early Morning Trevi Fountain Toss',
        description: 'Visit at 07:30 to beat crowds and toss a coin over left shoulder.',
        startTime: '07:30',
        endTime: '08:45',
        location: 'Piazza di Trevi, Rome',
        category: 'Sightseeing',
        cost: 5,
        currency: 'USD',
        priority: 'Low',
        isCompleted: false,
        coordinates: { lat: 41.9009, lng: 12.4833 },
      },
      {
        id: 'act-8',
        dayId: 'day-rome-3',
        tripId: 'trip-rome-2026',
        name: 'Villa Borghese Bicycle Rental & Gallery',
        description: 'Relaxed afternoon cycling through gardens and visiting the Borghese sculpture gallery.',
        startTime: '11:00',
        endTime: '15:00',
        location: 'Piazzale Scipione Borghese 5, Rome',
        category: 'Nature',
        cost: 45,
        currency: 'USD',
        priority: 'Medium',
        isCompleted: false,
        coordinates: { lat: 41.9142, lng: 12.4922 },
      },
    ],
  },
];

let EXPENSES = [
  {
    id: 'exp-1',
    tripId: 'trip-rome-2026',
    title: 'Roundtrip Flights (London Heathrow to Fiumicino)',
    amount: 720,
    currency: 'USD',
    category: 'Flights',
    date: '2026-09-01',
    paidById: 'usr-1',
    paidByName: 'Lara Croft',
    paymentMethod: 'Credit Card',
    notes: 'British Airways flight BA554 and BA557.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 360, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 360, settled: false },
    ],
  },
  {
    id: 'exp-2',
    tripId: 'trip-rome-2026',
    title: 'Hotel Artemide (5 Nights)',
    amount: 1100,
    currency: 'USD',
    category: 'Accommodation',
    date: '2026-09-15',
    paidById: 'usr-1',
    paidByName: 'Lara Croft',
    paymentMethod: 'Credit Card',
    notes: 'Superior Queen room with daily breakfast.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 550, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 550, settled: false },
    ],
  },
  {
    id: 'exp-3',
    tripId: 'trip-rome-2026',
    title: 'Colosseum & Vatican Guided Passes',
    amount: 195,
    currency: 'USD',
    category: 'Activities',
    date: '2026-09-20',
    paidById: 'usr-2',
    paidByName: 'Madhav Sharma',
    paymentMethod: 'UPI',
    notes: 'Skip-the-line official tickets for 2 adults.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 97.5, settled: false },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 97.5, settled: true },
    ],
  },
  {
    id: 'exp-4',
    tripId: 'trip-rome-2026',
    title: 'Airport Leonardo Express Train Transfers',
    amount: 56,
    currency: 'USD',
    category: 'Transportation',
    date: '2026-10-10',
    paidById: 'usr-2',
    paidByName: 'Madhav Sharma',
    paymentMethod: 'Credit Card',
    notes: 'Train tickets from Fiumicino to Roma Termini.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 28, settled: false },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 28, settled: true },
    ],
  },
  {
    id: 'exp-5',
    tripId: 'trip-rome-2026',
    title: 'Trattoria Monti Welcome Dinner',
    amount: 140,
    currency: 'USD',
    category: 'Food',
    date: '2026-10-10',
    paidById: 'usr-1',
    paidByName: 'Lara Croft',
    paymentMethod: 'Cash',
    notes: 'Pasta, starters, and house red wine.',
    splits: [
      { userId: 'usr-1', userName: 'Lara Croft', amount: 70, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: 70, settled: false },
    ],
  },
];

let GROUPS = [
  {
    id: 'grp-rome',
    name: 'Rome Explorers Squad',
    description: 'Planning discussions, shared budget, and itinerary sync for Rome Autumn 2026.',
    imageUrl: '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    tripId: 'trip-rome-2026',
    createdAt: '2026-02-01T10:00:00Z',
    members: [
      {
        userId: 'usr-1',
        name: 'Lara Croft',
        email: 'lara@tripnest.com',
        avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
        role: 'Owner',
        joinedAt: '2026-02-01T10:00:00Z',
      },
      {
        userId: 'usr-2',
        name: 'Madhav Sharma',
        email: 'madhav@tripnest.com',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'Admin',
        joinedAt: '2026-02-02T11:00:00Z',
      },
    ],
  },
  {
    id: 'grp-goa',
    name: 'Goa Coastal Crew',
    description: 'Beach hopping, scuba diving, and night market trip group.',
    imageUrl: '/src/assets/images/dest_goa_beach_1790172797821.jpg',
    tripId: 'trip-goa-2026',
    createdAt: '2026-02-12T09:00:00Z',
    members: [
      {
        userId: 'usr-2',
        name: 'Madhav Sharma',
        email: 'madhav@tripnest.com',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'Owner',
        joinedAt: '2026-02-12T09:00:00Z',
      },
    ],
  },
];

let DOCUMENTS = [
  {
    id: 'doc-1',
    tripId: 'trip-rome-2026',
    name: 'Schengen Visa Confirmation.pdf',
    category: 'Visa',
    fileSize: '1.4 MB',
    fileType: 'application/pdf',
    uploadDate: '2026-08-20',
    expiryDate: '2027-02-20',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Multi-entry Schengen visa valid for 90 days stay.',
  },
  {
    id: 'doc-2',
    tripId: 'trip-rome-2026',
    name: 'BA554 Flight Boarding Pass.pdf',
    category: 'Flight Tickets',
    fileSize: '820 KB',
    fileType: 'application/pdf',
    uploadDate: '2026-09-02',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Terminal 5 Heathrow, seats 14A & 14B.',
  },
  {
    id: 'doc-3',
    tripId: 'trip-rome-2026',
    name: 'Hotel Artemide Booking Voucher.pdf',
    category: 'Hotel Bookings',
    fileSize: '650 KB',
    fileType: 'application/pdf',
    uploadDate: '2026-09-15',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Check-in Oct 10 14:00, Check-out Oct 15 11:00.',
  },
  {
    id: 'doc-4',
    tripId: 'trip-rome-2026',
    name: 'Allianz Global Travel Insurance Policy.pdf',
    category: 'Travel Insurance',
    fileSize: '2.1 MB',
    fileType: 'application/pdf',
    uploadDate: '2026-08-25',
    expiryDate: '2026-11-01',
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: 'Comprehensive medical and flight cancellation coverage.',
  },
];

let NOTIFICATIONS = [
  {
    id: 'notif-1',
    title: 'Flight Check-in Reminder',
    message: 'Online check-in for flight BA554 to Rome opens in 48 hours.',
    type: 'TRIP',
    isRead: false,
    timestamp: '10 minutes ago',
    actionUrl: '/trips/trip-rome-2026',
  },
  {
    id: 'notif-2',
    title: 'Budget Milestone Alert',
    message: 'Rome Cultural Escape is at 76% of estimated expenditure ($2,450 / $3,200).',
    type: 'BUDGET',
    isRead: false,
    timestamp: '2 hours ago',
    actionUrl: '/trips/trip-rome-2026',
  },
  {
    id: 'notif-3',
    title: 'New Activity Proposal by TripNest AI',
    message: 'AI Copilot recommended an evening Trastevere Wine & Cheese walk based on your food preference.',
    type: 'AI',
    isRead: true,
    timestamp: '1 day ago',
    actionUrl: '/trips/trip-rome-2026',
  },
  {
    id: 'notif-4',
    title: 'Group Invitation Accepted',
    message: 'Madhav Sharma joined Rome Explorers Squad.',
    type: 'GROUP',
    isRead: true,
    timestamp: '3 days ago',
    actionUrl: '/groups',
  },
];

let FAVORITES = ['dest-rome', 'dest-bali', 'dest-paris'];

const DESTINATIONS = [
  {
    id: 'dest-rome',
    name: 'Rome',
    country: 'Italy',
    region: 'Southern Europe',
    category: 'Historical',
    rating: 4.9,
    shortDescription: 'The Eternal City with 2,800 years of living history, baroque fountains, and legendary cuisine.',
    longDescription: 'Rome is an epic outdoor museum where ancient colosseums rise alongside bustling espresso cafes, cobblestone alleyways, and the sovereign Vatican City.',
    imageUrl: '/src/assets/images/dest_rome_colosseum_1790172766150.jpg',
    averageCostPerDay: 160,
    bestTimeToVisit: 'April - May & September - October',
    currentWeather: { temp: 24, condition: 'Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Colosseum & Roman Forum', description: 'Grand amphitheater of gladiators and ancient political heart.', estimatedCost: 28 },
      { name: 'Vatican Museums & Sistine Chapel', description: 'Michelangelos fresco ceiling and papal collections.', estimatedCost: 32 },
      { name: 'Pantheon & Piazza Navona', description: 'Flawlessly preserved Roman temple with open dome oculus.', estimatedCost: 5 },
      { name: 'Trevi Fountain & Spanish Steps', description: 'Baroque masterpiece coin-toss fountain and rooftop views.', estimatedCost: 0 },
    ],
    travelTips: ['Always carry a refillable water bottle for Romes public nasoni fountains.', 'Book Vatican tickets at least 3 weeks ahead.', 'Tipping is not mandatory; rounded change is appreciated.'],
    safetyInfo: 'Very safe city; watch out for pickpockets on metro lines A and B.',
    coordinates: { lat: 41.9028, lng: 12.4964 },
  },
  {
    id: 'dest-bali',
    name: 'Bali',
    country: 'Indonesia',
    region: 'Southeast Asia',
    category: 'Beaches',
    rating: 4.8,
    shortDescription: 'Island of the Gods with lush emerald rice terraces, cliffside temples, and world-class surfing.',
    longDescription: 'From the cultural tranquility of Ubud to dramatic sunset sea cliffs at Uluwatu, Bali blends tropical wellness with vibrant island hospitality.',
    imageUrl: '/src/assets/images/dest_bali_temple_1790172783309.jpg',
    averageCostPerDay: 75,
    bestTimeToVisit: 'May - September',
    currentWeather: { temp: 29, condition: 'Tropical Breeze', icon: 'CloudSun' },
    topAttractions: [
      { name: 'Ulun Danu Bratan Water Temple', description: 'Iconic temple floating on Lake Bratan with volcanic backdrop.', estimatedCost: 5 },
      { name: 'Tegallalang Rice Terraces', description: 'Valley of verdant stepped emerald paddies and jungle swings.', estimatedCost: 4 },
      { name: 'Uluwatu Sunset Temple & Kecak Dance', description: 'Clifftop temple overlooking crashing Indian Ocean waves.', estimatedCost: 12 },
    ],
    travelTips: ['Rent a scooter only if you have an international driving permit.', 'Dress respectfully with a sarong when entering temples.'],
    safetyInfo: 'Safe destination; beware of wild monkeys snatching sunglasses at Uluwatu.',
    coordinates: { lat: -8.4095, lng: 115.1889 },
  },
  {
    id: 'dest-goa',
    name: 'Goa',
    country: 'India',
    region: 'South Asia',
    category: 'Beaches',
    rating: 4.7,
    shortDescription: 'Golden coastline fringed with palm trees, Portuguese cathedrals, and lively beach shacks.',
    longDescription: 'Goa offers a laid-back blend of susegad lifestyle, spice plantations, vibrant flea markets, water sports, and sunset drum circles.',
    imageUrl: '/src/assets/images/dest_goa_beach_1790172797821.jpg',
    averageCostPerDay: 50,
    bestTimeToVisit: 'November - February',
    currentWeather: { temp: 31, condition: 'Warm & Sunny', icon: 'Sun' },
    topAttractions: [
      { name: 'Palolem & Agonda Beaches', description: 'Pristine crescent bays with dolphin boat tours and beach huts.', estimatedCost: 0 },
      { name: 'Basilica of Bom Jesus', description: 'UNESCO World Heritage 16th-century baroque cathedral.', estimatedCost: 0 },
      { name: 'Dudhsagar Waterfalls Trek', description: 'Four-tiered milky white waterfall inside Bhagwan Mahavir Sanctuary.', estimatedCost: 20 },
    ],
    travelTips: ['North Goa is great for nightlife and water sports; South Goa is peaceful and pristine.', 'Try the authentic Goan fish curry with local poi bread.'],
    safetyInfo: 'Safe tourist destination; adhere to lifeguard beach flags regarding sea currents.',
    coordinates: { lat: 15.2993, lng: 74.124 },
  },
  {
    id: 'dest-paris',
    name: 'Paris',
    country: 'France',
    region: 'Western Europe',
    category: 'Popular',
    rating: 4.9,
    shortDescription: 'The City of Light, celebrated for haute couture, the Louvre, romantic Seine bridges, and cafe culture.',
    longDescription: 'Paris balances iconic architectural monuments with cobblestone artist corners in Montmartre, world-leading art galleries, and Michelin-starred dining.',
    imageUrl: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 190,
    bestTimeToVisit: 'June - August & September - October',
    currentWeather: { temp: 19, condition: 'Partly Cloudy', icon: 'Cloud' },
    topAttractions: [
      { name: 'Eiffel Tower & Champ de Mars', description: 'Wrought-iron lattice tower with panoramic observation decks.', estimatedCost: 30 },
      { name: 'Louvre Museum', description: 'Worlds largest art museum housing the Mona Lisa and Venus de Milo.', estimatedCost: 22 },
      { name: 'Musée d Orsay', description: 'Impressionist art housed in a magnificent former railway station.', estimatedCost: 16 },
    ],
    travelTips: ['Purchase Navigo Easy metro passes for convenience.', 'Many state museums are free on the first Sunday of each month.'],
    safetyInfo: 'Safe; be aware of petition scams and pickpockets near major attractions.',
    coordinates: { lat: 48.8566, lng: 2.3522 },
  },
  {
    id: 'dest-tokyo',
    name: 'Tokyo',
    country: 'Japan',
    region: 'East Asia',
    category: 'Trending',
    rating: 5.0,
    shortDescription: 'Ultra-modern metropolis seamlessly juxtaposed with quiet Shinto shrines and legendary ramen bars.',
    longDescription: 'From neon-lit Shibuya crossing to serene Meiji Jingu shrine, Tokyo represents the peak of efficiency, culinary craftsmanship, and urban innovation.',
    imageUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 175,
    bestTimeToVisit: 'March - May (Cherry Blossoms) & October - November',
    currentWeather: { temp: 18, condition: 'Clear', icon: 'Sun' },
    topAttractions: [
      { name: 'Senso-ji Temple Asakusa', description: 'Tokyos oldest Buddhist temple with Nakamise shopping street.', estimatedCost: 0 },
      { name: 'Shibuya Sky & Scramble Crossing', description: 'Open-air observation deck 229 meters above the worlds busiest crossing.', estimatedCost: 18 },
      { name: 'TeamLab Planets Immersive Art', description: 'Body-immersive digital art museum walking through water.', estimatedCost: 28 },
    ],
    travelTips: ['Get a digital Suica or Pasmo IC card on your phone for all trains and vending machines.', 'Trash cans are rare; keep a small bag with you.'],
    safetyInfo: 'One of the safest cities in the world.',
    coordinates: { lat: 35.6762, lng: 139.6503 },
  },
  {
    id: 'dest-london',
    name: 'London',
    country: 'United Kingdom',
    region: 'Western Europe',
    category: 'Popular',
    rating: 4.8,
    shortDescription: 'Historic global capital spanning the Thames, royal palaces, world-class West End theatres, and free museums.',
    longDescription: 'Explore the British Museum, watch the changing of the guard at Buckingham Palace, ride the London Eye, and stroll through Soho and Covent Garden.',
    imageUrl: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 185,
    bestTimeToVisit: 'May - September',
    currentWeather: { temp: 16, condition: 'Mild Rain', icon: 'CloudRain' },
    topAttractions: [
      { name: 'Tower of London & Crown Jewels', description: 'Historic castle fortress with yeoman warders and royal armory.', estimatedCost: 35 },
      { name: 'British Museum', description: 'Dedicated to human history, art and culture, housing the Rosetta Stone.', estimatedCost: 0 },
      { name: 'London Eye & Thames Cruise', description: 'Giant observation wheel with 360-degree skyline views.', estimatedCost: 38 },
    ],
    travelTips: ['Contactless payment cards work directly at all Underground turnstiles.', 'Major state museums (British Museum, V&A, Tate) are completely free.'],
    safetyInfo: 'Safe city; watch your mobile phone around busy road crossings.',
    coordinates: { lat: 51.5074, lng: -0.1278 },
  },
  {
    id: 'dest-dubai',
    name: 'Dubai',
    country: 'United Arab Emirates',
    region: 'Middle East',
    category: 'Luxury',
    rating: 4.8,
    shortDescription: 'Futuristic desert metropolis of soaring skyscrapers, luxury shopping, and golden dune safaris.',
    longDescription: 'Marvel at Burj Khalifa, the worlds tallest building, shop in the Dubai Mall, cruise Dubai Marina, and experience dune bashing under starry Arabian skies.',
    imageUrl: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&auto=format&fit=crop&q=80',
    averageCostPerDay: 220,
    bestTimeToVisit: 'November - March',
    currentWeather: { temp: 33, condition: 'Sunny & Warm', icon: 'Sun' },
    topAttractions: [
      { name: 'Burj Khalifa At The Top', description: 'Observation decks on levels 124 & 148 overlooking the Persian Gulf.', estimatedCost: 45 },
      { name: 'Desert Safari with BBQ Dinner', description: '4x4 dune bashing, camel rides, falconry, and traditional Tanoura dance.', estimatedCost: 55 },
      { name: 'Museum of the Future', description: 'Architectural wonder exploring future space technology and bio-design.', estimatedCost: 40 },
    ],
    travelTips: ['Dubai Metro is pristine and connects DXB airport directly to downtown.', 'Modest dress is respected in public malls and government buildings.'],
    safetyInfo: 'Extremely safe with virtually zero street crime.',
    coordinates: { lat: 25.2048, lng: 55.2708 },
  },
];

const CURRENCY_RATES = {
  USD: { code: 'USD', symbol: '$', name: 'US Dollar', rateAgainstUSD: 1.0 },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro', rateAgainstUSD: 0.92 },
  INR: { code: 'INR', symbol: '₹', name: 'Indian Rupee', rateAgainstUSD: 83.45 },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound', rateAgainstUSD: 0.79 },
  AED: { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham', rateAgainstUSD: 3.67 },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen', rateAgainstUSD: 154.2 },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', rateAgainstUSD: 1.52 },
  CAD: { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar', rateAgainstUSD: 1.36 },
  SGD: { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', rateAgainstUSD: 1.34 },
};

// -------------------------------------------------------------
// REST API ROUTES (Spring Boot REST API Parity)
// -------------------------------------------------------------

// Auth APIs
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  const user = USERS.find((u) => u.email.toLowerCase() === (email || '').toLowerCase()) || USERS[0];
  const token = `jwt_token_${user.id}_${Date.now()}`;
  res.json({
    success: true,
    message: 'Authentication successful',
    data: {
      user,
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: 86400,
    },
  });
});

app.post('/api/auth/register', (req: Request, res: Response) => {
  const { fullName, email, country, preferredCurrency, travelPreferences } = req.body;
  const newUser = {
    id: `usr-${Date.now()}`,
    fullName: fullName || 'New Traveler',
    email: email || `traveler${Date.now()}@tripnest.com`,
    avatarUrl: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
    country: country || 'United States',
    preferredCurrency: preferredCurrency || 'USD',
    travelPreferences: travelPreferences || ['Sightseeing', 'Food'],
    role: 'TRAVELER',
    createdAt: new Date().toISOString(),
  };
  USERS.push(newUser);
  const token = `jwt_token_${newUser.id}_${Date.now()}`;
  res.status(201).json({
    success: true,
    message: 'User registered successfully',
    data: {
      user: newUser,
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: 86400,
    },
  });
});

app.post('/api/auth/google', (req: Request, res: Response) => {
  const user = USERS[0];
  const token = `jwt_google_${user.id}_${Date.now()}`;
  res.json({
    success: true,
    message: 'Google OAuth authentication successful',
    data: {
      user,
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: 86400,
    },
  });
});

app.get('/api/auth/me', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  let user = USERS[0];
  if (authHeader && authHeader.includes('usr-2')) {
    user = USERS[1];
  } else if (authHeader && authHeader.includes('usr-admin')) {
    user = USERS[2];
  }
  res.json({
    success: true,
    data: user,
  });
});

// Trips APIs
app.get('/api/trips', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: TRIPS,
  });
});

app.get('/api/trips/upcoming', (req: Request, res: Response) => {
  const upcoming = TRIPS.filter((t) => t.status === 'UPCOMING' || t.status === 'PLANNING');
  res.json({
    success: true,
    data: upcoming,
  });
});

app.get('/api/trips/past', (req: Request, res: Response) => {
  const past = TRIPS.filter((t) => t.status === 'COMPLETED');
  res.json({
    success: true,
    data: past,
  });
});

app.get('/api/trips/:id', (req: Request, res: Response) => {
  const trip = TRIPS.find((t) => t.id === req.params.id);
  if (!trip) {
    return res.status(404).json({ success: false, message: 'Trip not found' });
  }
  res.json({ success: true, data: trip });
});

app.post('/api/trips', (req: Request, res: Response) => {
  const { tripName, description, destination, country, startDate, endDate, travelers, budget, currency, travelStyle, coverImage } = req.body;
  
  // Find destination coordinates if available
  const matchDest = DESTINATIONS.find((d) => d.name.toLowerCase() === (destination || '').toLowerCase());
  const coords = matchDest ? matchDest.coordinates : { lat: 41.9028, lng: 12.4964 };
  const fallbackImg = matchDest ? matchDest.imageUrl : '/src/assets/images/hero_travel_workspace_1790172750348.jpg';

  const newTrip = {
    id: `trip-${Date.now()}`,
    tripName: tripName || 'New Adventure',
    description: description || `Exploring ${destination}`,
    destination: destination || 'Rome',
    country: country || (matchDest ? matchDest.country : 'Italy'),
    startDate: startDate || new Date().toISOString().split('T')[0],
    endDate: endDate || new Date(Date.now() + 5 * 86400000).toISOString().split('T')[0],
    travelers: travelers ? parseInt(travelers) : 1,
    budget: budget ? parseFloat(budget) : 2000,
    spent: 0,
    currency: currency || 'USD',
    status: 'PLANNING',
    visibility: 'PRIVATE',
    coverImage: coverImage || fallbackImg,
    ownerId: 'usr-1',
    ownerName: 'Lara Croft',
    travelStyle: travelStyle || 'Standard',
    coordinates: coords,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  TRIPS.unshift(newTrip);

  // Generate initial Day 1 itinerary container
  const newDay = {
    id: `day-${Date.now()}-1`,
    tripId: newTrip.id,
    dayNumber: 1,
    date: newTrip.startDate,
    title: 'Arrival & Welcome',
    summary: `Arrive in ${newTrip.destination}, settle in, and explore the city center.`,
    activities: [
      {
        id: `act-${Date.now()}-1`,
        dayId: `day-${Date.now()}-1`,
        tripId: newTrip.id,
        name: `Arrive in ${newTrip.destination}`,
        description: 'Check in to accommodation and relax after journey.',
        startTime: '12:00',
        endTime: '14:00',
        location: `${newTrip.destination} Center`,
        category: 'Hotel',
        cost: 0,
        currency: newTrip.currency,
        priority: 'High',
        isCompleted: false,
        coordinates: coords,
      },
    ],
  };
  ITINERARY_DAYS.push(newDay);

  res.status(201).json({
    success: true,
    message: 'Trip created successfully',
    data: newTrip,
  });
});

app.put('/api/trips/:id', (req: Request, res: Response) => {
  const index = TRIPS.findIndex((t) => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: 'Trip not found' });
  }
  TRIPS[index] = {
    ...TRIPS[index],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  res.json({
    success: true,
    message: 'Trip updated successfully',
    data: TRIPS[index],
  });
});

app.delete('/api/trips/:id', (req: Request, res: Response) => {
  TRIPS = TRIPS.filter((t) => t.id !== req.params.id);
  ITINERARY_DAYS = ITINERARY_DAYS.filter((d) => d.tripId !== req.params.id);
  EXPENSES = EXPENSES.filter((e) => e.tripId !== req.params.id);
  res.json({
    success: true,
    message: 'Trip deleted successfully',
  });
});

// Itineraries & Activities APIs
app.get('/api/itineraries/trip/:tripId', (req: Request, res: Response) => {
  const days = ITINERARY_DAYS.filter((d) => d.tripId === req.params.tripId);
  res.json({
    success: true,
    data: days,
  });
});

app.post('/api/itineraries', (req: Request, res: Response) => {
  const { tripId, dayNumber, date, title, summary } = req.body;
  const newDay = {
    id: `day-${Date.now()}`,
    tripId,
    dayNumber: dayNumber || 1,
    date: date || new Date().toISOString().split('T')[0],
    title: title || `Day ${dayNumber}`,
    summary: summary || 'Planned exploration and leisure.',
    activities: [],
  };
  ITINERARY_DAYS.push(newDay);
  res.status(201).json({
    success: true,
    message: 'Itinerary day added successfully',
    data: newDay,
  });
});

app.post('/api/activities', (req: Request, res: Response) => {
  const { dayId, tripId, name, description, startTime, endTime, location, category, cost, currency, notes, priority, coordinates } = req.body;
  const day = ITINERARY_DAYS.find((d) => d.id === dayId);
  if (!day) {
    return res.status(404).json({ success: false, message: 'Itinerary day not found' });
  }

  const newActivity = {
    id: `act-${Date.now()}`,
    dayId,
    tripId,
    name: name || 'New Activity',
    description: description || '',
    startTime: startTime || '10:00',
    endTime: endTime || '12:00',
    location: location || 'City Landmark',
    category: category || 'Sightseeing',
    cost: cost ? parseFloat(cost) : 0,
    currency: currency || 'USD',
    notes: notes || '',
    priority: priority || 'Medium',
    isCompleted: false,
    coordinates: coordinates || { lat: 41.8902, lng: 12.4922 },
  };

  day.activities.push(newActivity);
  res.status(201).json({
    success: true,
    message: 'Activity created successfully',
    data: newActivity,
  });
});

app.put('/api/activities/:id', (req: Request, res: Response) => {
  let found = false;
  for (const day of ITINERARY_DAYS) {
    const actIndex = day.activities.findIndex((a) => a.id === req.params.id);
    if (actIndex !== -1) {
      day.activities[actIndex] = { ...day.activities[actIndex], ...req.body };
      found = true;
      return res.json({ success: true, message: 'Activity updated', data: day.activities[actIndex] });
    }
  }
  if (!found) {
    res.status(404).json({ success: false, message: 'Activity not found' });
  }
});

app.delete('/api/activities/:id', (req: Request, res: Response) => {
  for (const day of ITINERARY_DAYS) {
    day.activities = day.activities.filter((a) => a.id !== req.params.id);
  }
  res.json({ success: true, message: 'Activity deleted' });
});

app.patch('/api/activities/:id/toggle', (req: Request, res: Response) => {
  for (const day of ITINERARY_DAYS) {
    const act = day.activities.find((a) => a.id === req.params.id);
    if (act) {
      act.isCompleted = !act.isCompleted;
      return res.json({ success: true, data: act });
    }
  }
  res.status(404).json({ success: false, message: 'Activity not found' });
});

// Expenses & Budget APIs
app.get('/api/expenses/trip/:tripId', (req: Request, res: Response) => {
  const expenses = EXPENSES.filter((e) => e.tripId === req.params.tripId);
  res.json({ success: true, data: expenses });
});

app.post('/api/expenses', (req: Request, res: Response) => {
  const { tripId, title, amount, currency, category, date, paidById, paidByName, paymentMethod, notes, splits } = req.body;
  const numAmount = parseFloat(amount) || 0;
  const newExpense = {
    id: `exp-${Date.now()}`,
    tripId,
    title: title || 'Expense',
    amount: numAmount,
    currency: currency || 'USD',
    category: category || 'Other',
    date: date || new Date().toISOString().split('T')[0],
    paidById: paidById || 'usr-1',
    paidByName: paidByName || 'Lara Croft',
    paymentMethod: paymentMethod || 'Credit Card',
    notes: notes || '',
    splits: splits || [
      { userId: 'usr-1', userName: 'Lara Croft', amount: numAmount / 2, settled: true },
      { userId: 'usr-2', userName: 'Madhav Sharma', amount: numAmount / 2, settled: false },
    ],
  };

  EXPENSES.unshift(newExpense);

  // Update Trip spent amount
  const trip = TRIPS.find((t) => t.id === tripId);
  if (trip) {
    trip.spent = (trip.spent || 0) + numAmount;
  }

  res.status(201).json({
    success: true,
    message: 'Expense added successfully',
    data: newExpense,
  });
});

app.delete('/api/expenses/:id', (req: Request, res: Response) => {
  const exp = EXPENSES.find((e) => e.id === req.params.id);
  if (exp) {
    const trip = TRIPS.find((t) => t.id === exp.tripId);
    if (trip) {
      trip.spent = Math.max(0, (trip.spent || 0) - exp.amount);
    }
  }
  EXPENSES = EXPENSES.filter((e) => e.id !== req.params.id);
  res.json({ success: true, message: 'Expense deleted successfully' });
});

// Settlements calculation (who owes whom)
app.get('/api/expenses/settlements/:tripId', (req: Request, res: Response) => {
  const expenses = EXPENSES.filter((e) => e.tripId === req.params.tripId);
  const balances: Record<string, number> = {};

  for (const exp of expenses) {
    balances[exp.paidByName] = (balances[exp.paidByName] || 0) + exp.amount;
    for (const split of exp.splits) {
      balances[split.userName] = (balances[split.userName] || 0) - split.amount;
    }
  }

  const debtors: { name: string; amount: number }[] = [];
  const creditors: { name: string; amount: number }[] = [];

  for (const [name, balance] of Object.entries(balances)) {
    if (balance < -0.01) {
      debtors.push({ name, amount: -balance });
    } else if (balance > 0.01) {
      creditors.push({ name, amount: balance });
    }
  }

  const settlements: any[] = [];
  let dIdx = 0;
  let cIdx = 0;

  while (dIdx < debtors.length && cIdx < creditors.length) {
    const debtor = debtors[dIdx];
    const creditor = creditors[cIdx];
    const settleAmt = Math.min(debtor.amount, creditor.amount);

    settlements.push({
      fromUser: debtor.name,
      toUser: creditor.name,
      amount: Math.round(settleAmt * 100) / 100,
      currency: expenses[0]?.currency || 'USD',
    });

    debtor.amount -= settleAmt;
    creditor.amount -= settleAmt;

    if (debtor.amount < 0.01) dIdx++;
    if (creditor.amount < 0.01) cIdx++;
  }

  res.json({ success: true, data: settlements, balances });
});

// Destinations APIs
app.get('/api/destinations', (req: Request, res: Response) => {
  const { category, search } = req.query;
  let filtered = [...DESTINATIONS];
  if (category && category !== 'All') {
    filtered = filtered.filter((d) => d.category.toLowerCase() === String(category).toLowerCase());
  }
  if (search) {
    const q = String(search).toLowerCase();
    filtered = filtered.filter((d) => d.name.toLowerCase().includes(q) || d.country.toLowerCase().includes(q));
  }
  res.json({ success: true, data: filtered });
});

app.get('/api/destinations/:id', (req: Request, res: Response) => {
  const dest = DESTINATIONS.find((d) => d.id === req.params.id);
  if (!dest) {
    return res.status(404).json({ success: false, message: 'Destination not found' });
  }
  res.json({ success: true, data: dest });
});

// Groups APIs
app.get('/api/groups', (req: Request, res: Response) => {
  res.json({ success: true, data: GROUPS });
});

app.get('/api/groups/trip/:tripId', (req: Request, res: Response) => {
  const grp = GROUPS.find((g) => g.tripId === req.params.tripId);
  res.json({ success: true, data: grp || null });
});

app.post('/api/groups/:id/invite', (req: Request, res: Response) => {
  const { email, role } = req.body;
  const grp = GROUPS.find((g) => g.id === req.params.id);
  if (!grp) {
    return res.status(404).json({ success: false, message: 'Group not found' });
  }
  const newMember = {
    userId: `usr-${Date.now()}`,
    name: email.split('@')[0],
    email,
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    role: role || 'Member',
    joinedAt: new Date().toISOString(),
  };
  grp.members.push(newMember);
  res.json({ success: true, message: `Invitation sent to ${email}`, data: grp });
});

// Documents APIs
app.get('/api/documents/trip/:tripId', (req: Request, res: Response) => {
  const docs = DOCUMENTS.filter((d) => d.tripId === req.params.tripId);
  res.json({ success: true, data: docs });
});

app.post('/api/documents', (req: Request, res: Response) => {
  const { tripId, name, category, fileSize, expiryDate, notes } = req.body;
  const newDoc = {
    id: `doc-${Date.now()}`,
    tripId,
    name: name || 'Document.pdf',
    category: category || 'Other',
    fileSize: fileSize || '1.2 MB',
    fileType: 'application/pdf',
    uploadDate: new Date().toISOString().split('T')[0],
    expiryDate: expiryDate || undefined,
    fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    notes: notes || '',
  };
  DOCUMENTS.push(newDoc);
  res.status(201).json({ success: true, message: 'Document uploaded securely', data: newDoc });
});

app.delete('/api/documents/:id', (req: Request, res: Response) => {
  DOCUMENTS = DOCUMENTS.filter((d) => d.id !== req.params.id);
  res.json({ success: true, message: 'Document deleted successfully' });
});

// Notifications APIs
app.get('/api/notifications', (req: Request, res: Response) => {
  res.json({ success: true, data: NOTIFICATIONS });
});

app.patch('/api/notifications/:id/read', (req: Request, res: Response) => {
  const notif = NOTIFICATIONS.find((n) => n.id === req.params.id);
  if (notif) notif.isRead = true;
  res.json({ success: true, data: notif });
});

app.post('/api/notifications/read-all', (req: Request, res: Response) => {
  NOTIFICATIONS.forEach((n) => (n.isRead = true));
  res.json({ success: true, message: 'All notifications marked as read' });
});

// Favorites APIs
app.get('/api/favorites', (req: Request, res: Response) => {
  const favDestinations = DESTINATIONS.filter((d) => FAVORITES.includes(d.id));
  res.json({ success: true, data: favDestinations });
});

app.post('/api/favorites/toggle', (req: Request, res: Response) => {
  const { destinationId } = req.body;
  if (FAVORITES.includes(destinationId)) {
    FAVORITES = FAVORITES.filter((id) => id !== destinationId);
    return res.json({ success: true, isFavorited: false, message: 'Removed from favorites' });
  } else {
    FAVORITES.push(destinationId);
    return res.json({ success: true, isFavorited: true, message: 'Saved to favorites' });
  }
});

// Currency & Weather APIs
app.get('/api/currency/rates', (req: Request, res: Response) => {
  res.json({ success: true, data: CURRENCY_RATES });
});

app.get('/api/weather/:city', (req: Request, res: Response) => {
  const city = req.params.city || 'Rome';
  const match = DESTINATIONS.find((d) => d.name.toLowerCase() === city.toLowerCase());
  const baseTemp = match ? match.currentWeather.temp : 22;

  const weatherData = {
    city,
    currentTemp: baseTemp,
    condition: match ? match.currentWeather.condition : 'Partly Cloudy',
    humidity: 62,
    windSpeed: '12 km/h',
    icon: match ? match.currentWeather.icon : 'Sun',
    forecast: [
      { day: 'Today', date: 'Oct 10', temp: baseTemp, tempMin: baseTemp - 5, tempMax: baseTemp + 2, condition: 'Clear', humidity: 55, icon: 'Sun' },
      { day: 'Tomorrow', date: 'Oct 11', temp: baseTemp + 1, tempMin: baseTemp - 4, tempMax: baseTemp + 3, condition: 'Sunny', humidity: 50, icon: 'Sun' },
      { day: 'Day 3', date: 'Oct 12', temp: baseTemp - 2, tempMin: baseTemp - 6, tempMax: baseTemp, condition: 'Cloudy', humidity: 68, icon: 'Cloud' },
      { day: 'Day 4', date: 'Oct 13', temp: baseTemp, tempMin: baseTemp - 5, tempMax: baseTemp + 1, condition: 'Clear', humidity: 58, icon: 'Sun' },
      { day: 'Day 5', date: 'Oct 14', temp: baseTemp + 2, tempMin: baseTemp - 3, tempMax: baseTemp + 4, condition: 'Warm', humidity: 52, icon: 'Sun' },
    ],
  };
  res.json({ success: true, data: weatherData });
});

// Analytics APIs
app.get('/api/analytics/traveler', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      totalTrips: TRIPS.length,
      countriesVisited: 3,
      favoriteDestination: 'Rome',
      averageTripCost: 2800,
      totalSpending: TRIPS.reduce((acc, t) => acc + (t.spent || 0), 0),
      averageTripDuration: '5.2 Days',
      expensesByCategory: [
        { category: 'Flights', amount: 1450, percentage: 38 },
        { category: 'Accommodation', amount: 1200, percentage: 31 },
        { category: 'Food', amount: 480, percentage: 13 },
        { category: 'Activities', amount: 420, percentage: 11 },
        { category: 'Transportation', amount: 250, percentage: 7 },
      ],
      monthlyTrips: [
        { month: 'Jun', count: 1 },
        { month: 'Jul', count: 2 },
        { month: 'Aug', count: 1 },
        { month: 'Sep', count: 0 },
        { month: 'Oct', count: 2 },
        { month: 'Nov', count: 1 },
      ],
    },
  });
});

app.get('/api/analytics/admin', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      totalUsers: 1420,
      activeUsers: 840,
      totalTripsCreated: 3120,
      activeTrips: 185,
      totalExpensesLogged: 124500,
      topDestinations: [
        { name: 'Rome', tripsCount: 420 },
        { name: 'Bali', tripsCount: 380 },
        { name: 'Goa', tripsCount: 310 },
        { name: 'Paris', tripsCount: 290 },
        { name: 'Tokyo', tripsCount: 260 },
      ],
      recentUsers: USERS,
    },
  });
});

// Reports APIs
app.get('/api/reports/trip/:id', (req: Request, res: Response) => {
  const trip = TRIPS.find((t) => t.id === req.params.id);
  const itinerary = ITINERARY_DAYS.filter((d) => d.tripId === req.params.id);
  const expenses = EXPENSES.filter((e) => e.tripId === req.params.id);
  res.json({
    success: true,
    data: {
      trip,
      itinerary,
      expenses,
      generatedAt: new Date().toISOString(),
      summary: {
        totalDays: itinerary.length,
        totalActivities: itinerary.reduce((acc, d) => acc + d.activities.length, 0),
        totalExpenses: expenses.reduce((acc, e) => acc + e.amount, 0),
        budgetStatus: (trip?.spent || 0) <= (trip?.budget || 0) ? 'Within Budget' : 'Over Budget',
      },
    },
  });
});

// -------------------------------------------------------------
// AI COPILOT SERVICE (Google GenAI gemini-3.8-flash)
// -------------------------------------------------------------

app.post('/api/ai/chat', async (req: Request, res: Response) => {
  const { message, tripId, conversationHistory } = req.body;
  const currentTrip = TRIPS.find((t) => t.id === tripId) || TRIPS[0];
  const tripItinerary = ITINERARY_DAYS.filter((d) => d.tripId === currentTrip.id);
  const tripExpenses = EXPENSES.filter((e) => e.tripId === currentTrip.id);

  // If Gemini API client is available, call gemini-3.8-flash
  if (aiClient) {
    try {
      const prompt = `You are TripNest AI, an elite, friendly, and practical AI travel copilot.
Context about the current trip:
- Trip Name: ${currentTrip.tripName}
- Destination: ${currentTrip.destination}, ${currentTrip.country}
- Dates: ${currentTrip.startDate} to ${currentTrip.endDate}
- Travelers: ${currentTrip.travelers}
- Budget: ${currentTrip.currency} ${currentTrip.budget}
- Current Spent: ${currentTrip.currency} ${currentTrip.spent}
- Travel Style: ${currentTrip.travelStyle}
- Current Itinerary: ${JSON.stringify(
        tripItinerary.map((d) => ({
          day: d.dayNumber,
          title: d.title,
          activities: d.activities.map((a) => `${a.startTime} - ${a.name} (${a.category}, ${currentTrip.currency} ${a.cost})`),
        }))
      )}
- Logged Expenses: ${JSON.stringify(tripExpenses.map((e) => `${e.title}: ${currentTrip.currency} ${e.amount} (${e.category})`))}

User query: "${message}"

Respond with high quality, specific travel advice.
Format your response as a valid JSON object matching this structure:
{
  "reply": "Your clear, formatted message to the traveler (markdown allowed)",
  "actions": [
    {
      "id": "act-proposal-1",
      "type": "ADD_ACTIVITY" | "OPTIMIZE_BUDGET" | "REARRANGE_ITINERARY" | "GENERATE_PACKING_LIST",
      "label": "Short button label, e.g. Add Trastevere Food Tour",
      "description": "Short explanation of the proposed change",
      "payload": {}
    }
  ]
}
If no explicit action is needed, return empty actions array. Return ONLY raw JSON without markdown code fences.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      let jsonText = response.text || '';
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      const parsed = JSON.parse(jsonText);
      return res.json({
        success: true,
        data: {
          reply: parsed.reply,
          actions: parsed.actions || [],
        },
      });
    } catch (err) {
      console.warn('Gemini API call fallback to intelligent engine:', err);
    }
  }

  // Intelligent domain-grounded fallback if Gemini API is offline or key missing
  const lowerMsg = (message || '').toLowerCase();
  let reply = '';
  const actions: any[] = [];

  if (lowerMsg.includes('budget') || lowerMsg.includes('cheaper') || lowerMsg.includes('cost') || lowerMsg.includes('save')) {
    reply = `Based on your budget of **${currentTrip.currency} ${currentTrip.budget}** and current spend of **${currentTrip.currency} ${currentTrip.spent}** for ${currentTrip.destination}:\n\n` +
      `1. **Accommodation**: Your hotel takes up ~45% of total budget. Booking an authorized boutique guesthouse in Monti or Trastevere can save ~$350.\n` +
      `2. **Dining**: Dine at family-run *osterie* on side streets rather than piazza fronts (savings: 30-40% per meal).\n` +
      `3. **Transport**: Use transit passes (Roma Pass or Metro passes) instead of taxis.`;
    actions.push({
      id: `opt-${Date.now()}`,
      type: 'OPTIMIZE_BUDGET',
      label: 'Apply 15% Budget Optimization',
      description: 'Shifts projected dining and transport estimates down to reflect local recommendations.',
      payload: { targetSavingsPercentage: 15 },
    });
  } else if (lowerMsg.includes('itinerary') || lowerMsg.includes('plan') || lowerMsg.includes('day')) {
    reply = `Here is a curated itinerary optimization for **${currentTrip.destination}**:\n\n` +
      `• **Day 1**: Arrival, check-in, Colosseum & Roman Forum VIP access, sunset dinner at Trattoria Monti.\n` +
      `• **Day 2**: Vatican Museums early access (08:30), St. Peter's Dome climb, evening stroll & natural wine in Trastevere.\n` +
      `• **Day 3**: Trevi Fountain early toss, Spanish Steps, bicycle rental in Villa Borghese gardens.\n\n` +
      `All locations have been clustered by proximity to minimize walking and transit delays.`;
    actions.push({
      id: `act-${Date.now()}`,
      type: 'ADD_ACTIVITY',
      label: 'Add Secret Food Walk to Day 2',
      description: 'Adds an evening 2-hour guided artisan gelato and pizza tasting in Trastevere.',
      payload: {
        dayNumber: 2,
        name: 'Trastevere Artisan Food & Gelato Walk',
        description: 'Taste authentic supplì, trapizzino, and artisanal pistachio gelato.',
        startTime: '17:30',
        endTime: '19:30',
        location: 'Trastevere Piazza, Rome',
        category: 'Food',
        cost: 45,
        priority: 'High',
      },
    });
  } else if (lowerMsg.includes('pack') || lowerMsg.includes('packing')) {
    reply = `Here is your customized packing checklist for **${currentTrip.destination}** in ${currentTrip.startDate.split('-')[1]} (Average 22-26°C):\n\n` +
      `🎒 **Essential Documents**: Passport, Schengen Visa copy, hotel reservations, international travel insurance card.\n` +
      `👟 **Footwear**: Broken-in walking sneakers with arch support (Rome has uneven basalt cobblestones).\n` +
      `👗 **Attire**: Breathable layers, lightweight cardigan for evenings, modest scarf/shawl for entering sacred churches.\n` +
      `🔌 **Electronics**: European Type C/F plug adapters, 10,000mAh power bank for all-day navigation.`;
    actions.push({
      id: `pack-${Date.now()}`,
      type: 'GENERATE_PACKING_LIST',
      label: 'Save Packing Checklist to Trip Notes',
      description: 'Embeds this structured packing list into your trip workspace.',
      payload: { destination: currentTrip.destination },
    });
  } else {
    reply = `I am your **TripNest AI Copilot** for **${currentTrip.destination}**! I have full visibility into your ${currentTrip.travelers}-person itinerary, budget (${currentTrip.currency} ${currentTrip.budget}), and booked activities.\n\n` +
      `I can help you with:\n` +
      `• **Build or reorder day-wise itineraries** based on geography\n` +
      `• **Optimize spending & find hidden savings**\n` +
      `• **Suggest authentic dining & attractions**\n` +
      `• **Generate dynamic packing lists** based on local weather`;
  }

  res.json({
    success: true,
    data: {
      reply,
      actions,
    },
  });
});

app.post('/api/ai/plan-trip', async (req: Request, res: Response) => {
  const { destination, days = 4, budget, currency = 'USD', travelStyle = 'Standard', travelers = 2 } = req.body;

  if (aiClient) {
    try {
      const prompt = `Generate a realistic, detailed ${days}-day travel itinerary for ${travelers} travelers visiting ${destination}.
Travel style: ${travelStyle}. Budget: ${currency} ${budget}.
Return a strict JSON object with this exact shape:
{
  "tripName": "${destination} Highlights & Culture",
  "description": "Curated ${days}-day journey through ${destination}",
  "days": [
    {
      "dayNumber": 1,
      "title": "Day 1 Title",
      "summary": "Day 1 summary",
      "activities": [
        {
          "name": "Activity Name",
          "description": "Description",
          "startTime": "09:00",
          "endTime": "11:00",
          "location": "Specific location in ${destination}",
          "category": "Sightseeing",
          "cost": 25,
          "priority": "High"
        }
      ]
    }
  ]
}
Return ONLY valid JSON.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      let jsonText = response.text || '';
      jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
      const parsed = JSON.parse(jsonText);
      return res.json({ success: true, data: parsed });
    } catch (err) {
      console.warn('AI Plan Trip fallback:', err);
    }
  }

  // Pre-crafted high-fidelity itinerary template for quick fallback
  const generatedPlan = {
    tripName: `${destination} Grand Experience`,
    description: `A masterfully balanced ${days}-day itinerary covering historic wonders, local dining, and relaxing evening sights in ${destination}.`,
    days: Array.from({ length: Math.min(days, 5) }, (_, i) => ({
      dayNumber: i + 1,
      title: i === 0 ? 'Arrival & Historic Landmarks' : i === 1 ? 'Cultural Immersion & Art' : i === 2 ? 'Local Gastronomy & Scenic Views' : `Day ${i + 1} Hidden Gems & Leisure`,
      summary: `Day ${i + 1} in ${destination} focusing on top landmarks and authentic culinary experiences.`,
      activities: [
        {
          name: `Morning Highlights in ${destination}`,
          description: 'Explore the most celebrated historical landmark with early access.',
          startTime: '09:30',
          endTime: '12:00',
          location: `${destination} Central District`,
          category: 'Sightseeing',
          cost: 35,
          priority: 'High',
        },
        {
          name: 'Artisan Lunch & Food Market',
          description: 'Sample local specialties and fresh seasonal dishes at the central food market.',
          startTime: '12:30',
          endTime: '14:00',
          location: `${destination} Market Square`,
          category: 'Food',
          cost: 25,
          priority: 'Medium',
        },
        {
          name: 'Scenic Sunset Walk & Viewpoint',
          description: 'Panoramic city vista followed by evening drinks.',
          startTime: '18:00',
          endTime: '19:30',
          location: `${destination} Panorama Deck`,
          category: 'Entertainment',
          cost: 15,
          priority: 'Medium',
        },
      ],
    })),
  };

  res.json({ success: true, data: generatedPlan });
});

// Endpoint to download the entire codebase as a ZIP file
app.get('/api/download-zip', (_req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'public', 'tripnest-codebase.zip');
  res.download(zipPath, 'tripnest-complete-codebase.zip', (err) => {
    if (err && !res.headersSent) {
      res.status(500).json({ error: 'Failed to download zip file' });
    }
  });
});

// -------------------------------------------------------------
// VITE INTEGRATION & SERVER STARTUP
// -------------------------------------------------------------

async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TripNest server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
